#!/bin/bash
# Round 69: إعادة بناء بيئة javac السريعة في /tmp (تمحى بين الجلسات).
# الاستخدام: bash /home/user/tools/rebuild_build_env.sh
set -e
mkdir -p /tmp/build67/ax /tmp/build67/gen/com/almlk/swiftkey /tmp/build69
cd /tmp/build67
[ -f android-13/android.jar ] || {
  curl -sS -o platform.zip https://dl.google.com/android/repository/platform-33_r02.zip
  unzip -o -q platform.zip
  rm -f platform.zip
}
AARS="androidx/appcompat/appcompat/1.6.1 appcompat-1.6.1
androidx/recyclerview/recyclerview/1.3.0 recyclerview-1.3.0
androidx/core/core/1.9.0 core-1.9.0
androidx/fragment/fragment/1.5.7 fragment-1.5.7
androidx/activity/activity/1.6.1 activity-1.6.1
androidx/lifecycle/lifecycle-runtime/2.5.1 lifecycle-runtime-2.5.1
androidx/lifecycle/lifecycle-viewmodel/2.5.1 lifecycle-viewmodel-2.5.1
androidx/lifecycle/lifecycle-livedata-core/2.5.1 lifecycle-livedata-core-2.5.1
androidx/lifecycle/lifecycle-viewmodel-savedstate/2.5.1 lifecycle-viewmodel-savedstate-2.5.1
androidx/savedstate/savedstate/1.2.0 savedstate-1.2.0
androidx/vectordrawable/vectordrawable/1.1.0 vectordrawable-1.1.0
androidx/vectordrawable/vectordrawable-animated/1.1.0 vectordrawable-animated-1.1.0
androidx/customview/customview/1.1.0 customview-1.1.0
androidx/interpolator/interpolator/1.0.0 interpolator-1.0.0
androidx/startup/startup-runtime/1.1.1 startup-runtime-1.1.1
androidx/drawerlayout/drawerlayout/1.1.1 drawerlayout-1.1.1
com/google/android/material/material/1.8.0 material-1.8.0"
echo "$AARS" | while read path name; do
  [ -f "ax/$name.jar" ] || {
    curl -sS -o /tmp/a.aar "https://dl.google.com/dl/android/maven2/$path/$name.aar"
    unzip -p /tmp/a.aar classes.jar > "ax/$name.jar"
  }
done
JARS="androidx/lifecycle/lifecycle-common/2.5.1 lifecycle-common-2.5.1
androidx/annotation/annotation/1.5.0 annotation-1.5.0
androidx/arch/core/core-common/2.1.0 core-common-2.1.0"
echo "$JARS" | while read path name; do
  [ -f "ax/$name.jar" ] || curl -sS -o "ax/$name.jar" "https://dl.google.com/dl/android/maven2/$path/$name.jar"
done
[ -f gen/com/almlk/swiftkey/R.java ] || python3 /home/user/tools/gen_r.py
echo "BUILD ENV READY: $(ls ax | wc -l) jars"
