# Round 69: مولّد R.java يدوي (بدون aapt) — يغطي كل الأنواع المستخدمة في
# الكود: layout/id/string/color/dimen/array/style/drawable/xml.
import os, re, collections
RES = '/home/user/SwiftKeyIME/app/src/main/res'
R = collections.OrderedDict((t, []) for t in
    ('array','color','dimen','drawable','id','layout','string','style','xml'))

def add(t, n):
    if n not in R[t]:
        R[t].append(n)

for d, t in (('drawable','drawable'),('drawable-anydpi-v21','drawable'),
             ('drawable-mdpi','drawable'),('drawable-nodpi','drawable'),
             ('layout','layout'),('xml','xml')):
    p = os.path.join(RES, d)
    if os.path.isdir(p):
        for f in sorted(os.listdir(p)):
            add(t, os.path.splitext(f)[0])

for d in sorted(x for x in os.listdir(RES) if x.startswith('values')):
    for f in sorted(os.listdir(os.path.join(RES, d))):
        src = open(os.path.join(RES, d, f), encoding='utf-8').read()
        for m in re.finditer(r'<(string|color|dimen|style)\b[^>]*\bname="([^"]+)"', src):
            add(m.group(1), m.group(2))
        for m in re.finditer(r'<(?:integer-array|string-array)\b[^>]*\bname="([^"]+)"', src):
            add('array', m.group(1))
        for m in re.finditer(r'<item\s+type="id"\s+name="([^"]+)"', src):
            add('id', m.group(1))

for f in sorted(os.listdir(os.path.join(RES, 'layout'))):
    src = open(os.path.join(RES, 'layout', f), encoding='utf-8').read()
    for m in re.finditer(r'@\+id/([A-Za-z_0-9]+)', src):
        add('id', m.group(1))

out = ['package com.almlk.swiftkey;', '', 'public final class R {']
order = list(R)
for t, names in R.items():
    out.append('  public static final class %s {' % t)
    for i, n in enumerate(names):
        out.append('    public static final int %s = 0x%08x;' % (n, 0x7f000000 | (order.index(t) << 20) | (i + 1)))
    out.append('  }')
out.append('}')
os.makedirs('/tmp/build67/gen/com/almlk/swiftkey', exist_ok=True)
open('/tmp/build67/gen/com/almlk/swiftkey/R.java', 'w', encoding='utf-8').write('\n'.join(out) + '\n')
print(sum(len(v) for v in R.values()), 'entries')
