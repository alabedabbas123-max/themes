# -*- coding: utf-8 -*-
"""Round 50 — توليد الإطارات الاحترافية العشرة كصور PNG حقيقية.

كل إطار يُرسم في 6 أشكال (مربع/خفيف/متوسط/دائري/كبير/كبسولة) بحيث تبدّل
الاستوديو الصورة ديناميكياً حسب الشكل المختار. زائد 6 صور مخططات للأشكال
نفسها (keyshape_*) لشريط الأشكال الأول كما في صورة المالك.
"""
import os
import random
from PIL import Image, ImageDraw, ImageFilter

OUT = "/tmp/gen50"
os.makedirs(OUT, exist_ok=True)

W, H = 240, 144          # مقاس الفن
M = 8                    # هامش للّمعان/الوهج الخارجي
KX0, KY0, KX1, KY1 = M, M, W - M, H - M     # مستطيل الزر 224×128
KH = KY1 - KY0
# نصف القطر كنسبة من ارتفاع الزر (ارتفاع الزر الحقيقي ≈ 46dp):
# r_dp/46 × 128px — و28/36 تُقصّان لنصف الارتفاع (كبسولة) كما يفعل drawRoundRect.
RADIUS = {0: 0, 5: 14, 10: 28, 17: 47, 28: 64, 36: 64}


def vgrad(size, stops):
    """تدرج عمودي: stops = [(موضع 0..1, (r,g,b,a)), ...] بمقاطع متتالية."""
    w, h = size
    img = Image.new("RGBA", size, (0, 0, 0, 0))
    dr = ImageDraw.Draw(img)
    for i in range(len(stops) - 1):
        p0, c0 = stops[i]
        p1, c1 = stops[i + 1]
        y0, y1 = int(round(p0 * h)), int(round(p1 * h))
        if y1 <= y0:
            y1 = y0 + 1
        for y in range(y0, min(y1, h)):
            t = (y - y0) / float(y1 - y0)
            col = tuple(int(c0[k] + (c1[k] - c0[k]) * t) for k in range(4))
            dr.line([(0, y), (w, y)], fill=col)
    return img


def mask_key(size, r, inset=0):
    """قناع L للزر بحواف دائرية (مع تقليص اختياري)."""
    m = Image.new("L", size, 0)
    d = ImageDraw.Draw(m)
    rad = max(0, min(RADIUS[r] - inset, (KH - 2 * inset) // 2))
    d.rounded_rectangle(
        [KX0 + inset, KY0 + inset, KX1 - inset, KY1 - inset], radius=rad, fill=255)
    return m


def clip_to_key(layer, r, inset=0):
    """يقصّ طبقة إلى شكل الزر (يحافظ على ألوانها وألفاها)."""
    return Image.composite(layer, Image.new("RGBA", layer.size, (0, 0, 0, 0)),
                           mask_key(layer.size, r, inset))


def paste_face(img, face, r):
    """يلصق وجه الزر مقصوصاً بشكله."""
    clipped = clip_to_key(face, r)
    img.paste(clipped, (0, 0), clipped)
    return img


def stroke_key(size, r, width, color, inset=0):
    """طبقة فيها حد الزر فقط."""
    s = Image.new("RGBA", size, (0, 0, 0, 0))
    d = ImageDraw.Draw(s)
    rad = max(0, min(RADIUS[r] - inset, (KH - 2 * inset) // 2))
    d.rounded_rectangle(
        [KX0 + inset, KY0 + inset, KX1 - inset, KY1 - inset],
        radius=rad, outline=color, width=width)
    return s


def gloss(r, top_frac=0.45, alpha=120, inset=5):
    """لمعة علوية داخل الزر تتلاشى لأسفل."""
    g = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    gh = int((KY1 - KY0) * top_frac)
    rad = max(0, min(RADIUS[r] - inset, gh // 2))
    d.rounded_rectangle([KX0 + inset, KY0 + inset, KX1 - inset, KY0 + inset + gh],
                        radius=rad, fill=(255, 255, 255, alpha))
    fade = vgrad((W, H), [(0, (255, 255, 255, alpha)),
                          (top_frac, (255, 255, 255, 0))])
    return clip_to_key(Image.composite(fade, Image.new("RGBA", (W, H), (0, 0, 0, 0)),
                                       g.split()[3]), r, inset)


def bottom_bevel(r, alpha=110, depth=14, inset=3, color=(0, 0, 0)):
    """حافة سفلية داكنة (عمق ثلاثي الأبعاد)."""
    fade = vgrad((W, H), [((KY1 - depth) / float(H), color + (alpha,)),
                          (1, color + (0,))])
    return clip_to_key(fade, r, inset)


def diagonal_streak(r, color=(255, 255, 255), alpha=80, width=26, offset=-30, inset=3):
    """شريط ضوء مائل لامع."""
    s = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(s)
    x = KX0 + offset
    while x < KX1 + H:
        d.polygon([(x, KY1), (x + width, KY1), (x + width + H, KY0), (x + H, KY0)],
                  fill=color + (alpha,))
        x += width * 9
    return clip_to_key(s, r, inset)


# ---------------------------------------------------------------- التصاميم
def frame_neon(r):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    face = vgrad((W, H), [(0, (18, 24, 32, 255)), (.5, (10, 14, 20, 255)),
                          (1, (5, 7, 11, 255))])
    paste_face(img, face, r)
    glow = stroke_key((W, H), r, 9, (41, 230, 255, 150)).filter(ImageFilter.GaussianBlur(9))
    img = Image.alpha_composite(glow, img)
    glow2 = stroke_key((W, H), r, 5, (41, 230, 255, 120)).filter(ImageFilter.GaussianBlur(4))
    img = Image.alpha_composite(img, glow2)
    img = Image.alpha_composite(img, stroke_key((W, H), r, 5, (58, 234, 255, 255)))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 2, (185, 251, 255, 150), inset=7))
    pink = stroke_key((W, H), r, 2, (255, 79, 216, 120), inset=10)
    img = Image.alpha_composite(img, pink.filter(ImageFilter.GaussianBlur(1)))
    img = Image.alpha_composite(img, gloss(r, .38, 34, 8))
    return img


def _solid_glossy(r, stops, inner, outer, bevel=110, streak=None, gloss_a=115):
    """قالب الأزرار المصقولة الصلبة."""
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    face = vgrad((W, H), stops)
    paste_face(img, face, r)
    if streak:
        img = Image.alpha_composite(img, diagonal_streak(r, streak[0], streak[1], 24))
    img = Image.alpha_composite(img, gloss(r, .45, gloss_a, 5))
    img = Image.alpha_composite(img, bottom_bevel(r, bevel, 13, 3))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 2, outer))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 2, inner, inset=5))
    return img


def frame_gold(r):
    return _solid_glossy(
        r,
        [(0, (249, 231, 160, 255)), (.38, (231, 200, 106, 255)),
         (.78, (200, 154, 46, 255)), (1, (143, 100, 18, 255))],
        inner=(255, 246, 207, 195), outer=(122, 85, 16, 255))


def frame_glass(r):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    face = vgrad((W, H), [(0, (234, 244, 255, 96)), (1, (214, 228, 244, 70))])
    paste_face(img, face, r)
    img = Image.alpha_composite(img, gloss(r, .42, 92, 4))
    img = Image.alpha_composite(img, diagonal_streak(r, (255, 255, 255), 70, 20, -34))
    shade = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(shade)
    d.rectangle([KX0, KY1 - 10, KX1, KY1], fill=(159, 180, 200, 80))
    img = Image.alpha_composite(img, clip_to_key(shade, r, 4))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 3, (255, 255, 255, 215)))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 1, (255, 255, 255, 120), inset=6))
    return img


def frame_silver(r):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    face = vgrad((W, H), [(0, (242, 244, 247, 255)), (.4, (205, 211, 219, 255)),
                          (.82, (172, 179, 189, 255)), (1, (140, 147, 158, 255))])
    paste_face(img, face, r)
    # خدش معدني أفقي (فرشاة)
    brush = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(brush)
    rnd = random.Random(7)
    for y in range(KY0 + 3, KY1 - 3, 2):
        a = rnd.randint(10, 34)
        col = (255, 255, 255, a) if rnd.random() < .5 else (60, 66, 76, a)
        x0 = KX0 + rnd.randint(0, 30)
        x1 = KX1 - rnd.randint(0, 30)
        d.line([(x0, y), (x1, y)], fill=col)
    img = Image.alpha_composite(img, clip_to_key(brush, r, 3))
    img = Image.alpha_composite(img, gloss(r, .4, 95, 5))
    img = Image.alpha_composite(img, bottom_bevel(r, 90, 12, 3))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 2, (125, 133, 144, 255)))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 1, (255, 255, 255, 170), inset=5))
    return img


def frame_rose(r):
    return _solid_glossy(
        r,
        [(0, (255, 217, 230, 255)), (.4, (246, 168, 200, 255)),
         (.8, (212, 117, 159, 255)), (1, (178, 88, 130, 255))],
        inner=(255, 233, 242, 190), outer=(160, 78, 112, 255))


def frame_carbon(r):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    face = Image.new("RGBA", (W, H), (18, 23, 28, 255))
    d = ImageDraw.Draw(face)
    cell = 14
    for cy in range(KY0, KY1, cell):
        for cx in range(KX0, KX1, cell):
            odd = ((cx // cell) + (cy // cell)) % 2 == 1
            c0 = (26, 32, 39, 255) if odd else (13, 16, 21, 255)
            c1 = (13, 16, 21, 255) if odd else (26, 32, 39, 255)
            for i in range(cell):
                t = i / float(cell)
                col = tuple(int(c0[k] + (c1[k] - c0[k]) * t) for k in range(4))
                d.line([(cx, cy + i), (min(cx + cell, KX1), cy + i)], fill=col)
    paste_face(img, face, r)
    sheen = vgrad((W, H), [(0, (255, 255, 255, 26)), (.5, (255, 255, 255, 0))])
    img = Image.alpha_composite(img, clip_to_key(sheen, r, 2))
    # حد أحمر متوهج
    glow = stroke_key((W, H), r, 7, (255, 64, 64, 110)).filter(ImageFilter.GaussianBlur(5))
    img = Image.alpha_composite(glow, img)
    img = Image.alpha_composite(img, stroke_key((W, H), r, 4, (255, 64, 64, 255)))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 1, (139, 147, 158, 120), inset=7))
    return img


def frame_emerald(r):
    return _solid_glossy(
        r,
        [(0, (99, 230, 165, 255)), (.34, (18, 160, 95, 255)),
         (.8, (11, 93, 58, 255)), (1, (6, 64, 39, 255))],
        inner=(169, 255, 212, 170), outer=(8, 61, 38, 255),
        streak=((220, 255, 238), 70), gloss_a=100)


def frame_sapphire(r):
    return _solid_glossy(
        r,
        [(0, (134, 185, 255, 255)), (.36, (53, 111, 224, 255)),
         (.8, (27, 63, 143, 255)), (1, (16, 38, 90, 255))],
        inner=(214, 232, 255, 170), outer=(14, 34, 78, 255),
        streak=((235, 244, 255), 85), gloss_a=110)


def frame_royal(r):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    face = vgrad((W, H), [(0, (74, 53, 128, 255)), (.45, (52, 36, 92, 255)),
                          (1, (35, 23, 68, 255))])
    paste_face(img, face, r)
    img = Image.alpha_composite(img, gloss(r, .4, 60, 5))
    img = Image.alpha_composite(img, bottom_bevel(r, 80, 11, 3))
    # إطار ذهبي مزدوج + نقاط ملكية بالزوايا
    img = Image.alpha_composite(img, stroke_key((W, H), r, 5, (232, 200, 90, 255)))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 2, (247, 230, 168, 210), inset=8))
    dots = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dd = ImageDraw.Draw(dots)
    for cx, cy in [(KX0 + 13, KY0 + 13), (KX1 - 13, KY0 + 13),
                   (KX0 + 13, KY1 - 13), (KX1 - 13, KY1 - 13)]:
        dd.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], fill=(247, 230, 168, 235))
    img = Image.alpha_composite(img, dots)
    return img


def frame_sunset(r):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    # تدرج أفقي (غروب)
    face = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(face)
    c0, c1, c2 = (255, 196, 107, 255), (255, 142, 110, 255), (247, 92, 138, 255)
    for x in range(KX0, KX1):
        t = (x - KX0) / float(KX1 - KX0)
        if t < .5:
            u = t / .5
            col = tuple(int(c0[k] + (c1[k] - c0[k]) * u) for k in range(4))
        else:
            u = (t - .5) / .5
            col = tuple(int(c1[k] + (c2[k] - c1[k]) * u) for k in range(4))
        d.line([(x, KY0), (x, KY1)], fill=col)
    paste_face(img, face, r)
    glow = stroke_key((W, H), r, 6, (255, 217, 160, 95)).filter(ImageFilter.GaussianBlur(4))
    img = Image.alpha_composite(glow, img)
    img = Image.alpha_composite(img, gloss(r, .44, 105, 5))
    img = Image.alpha_composite(img, diagonal_streak(r, (255, 255, 255), 60, 18, -20))
    img = Image.alpha_composite(img, bottom_bevel(r, 95, 12, 3))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 3, (255, 219, 168, 225)))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 1, (255, 255, 255, 140), inset=6))
    return img


FRAMES = [
    ("neon", frame_neon),
    ("gold", frame_gold),
    ("glass", frame_glass),
    ("silver", frame_silver),
    ("rose", frame_rose),
    ("carbon", frame_carbon),
    ("emerald", frame_emerald),
    ("sapphire", frame_sapphire),
    ("royal", frame_royal),
    ("sunset", frame_sunset),
]

total = 0
for name, fn in FRAMES:
    for r in RADIUS:
        art = fn(r)
        path = os.path.join(OUT, "keyframe_%s_%d.png" % (name, r))
        art.save(path, optimize=True)
        total += os.path.getsize(path)

# مخططات الأشكال لشريط الأشكال الأول (كما في صورة المالك: حد رفيع + تعبئة فاتحة)
for r in RADIUS:
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    face = Image.new("RGBA", (W, H), (243, 245, 248, 255))
    paste_face(img, face, r)
    img = Image.alpha_composite(img, stroke_key((W, H), r, 4, (74, 85, 97, 255)))
    img = Image.alpha_composite(img, stroke_key((W, H), r, 1, (255, 255, 255, 150), inset=6))
    path = os.path.join(OUT, "keyshape_%d.png" % r)
    img.save(path, optimize=True)
    total += os.path.getsize(path)

print("files:", len(os.listdir(OUT)), "total bytes:", total)
