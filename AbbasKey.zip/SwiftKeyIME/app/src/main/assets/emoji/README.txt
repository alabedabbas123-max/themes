emoji_data.tsv is generated from the Unicode emoji test data.
emoji_search_ar_en.tsv combines every emoji in emoji_data.tsv with Arabic and English search annotations from Unicode CLDR annotations and annotationsDerived.
Unicode data files and software are covered by the Unicode License v3: https://www.unicode.org/license.txt
No emoji search data is uploaded by the keyboard.
