package com.almlk.swiftkey.ime;

/** Tiny AIDE bridge; the verified implementation is AlmlkImeRuntime. */
public class AlmlkImeServiceCore extends AlmlkImeRuntime {}
