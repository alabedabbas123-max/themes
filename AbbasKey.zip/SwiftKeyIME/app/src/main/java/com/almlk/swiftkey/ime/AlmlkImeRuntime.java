package com.almlk.swiftkey.ime;

/** Final, intentionally empty AIDE-safe runtime bridge. */
public class AlmlkImeRuntime extends AlmlkImeRuntimePart5 {}
