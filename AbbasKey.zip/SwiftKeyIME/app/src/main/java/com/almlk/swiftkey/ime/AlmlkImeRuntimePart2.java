package com.almlk.swiftkey.ime;

/** Empty compatibility bridge; implementation is divided into Part2A, Part2B and Part2C. */
public abstract class AlmlkImeRuntimePart2 extends AlmlkImeRuntimePart2C {}
