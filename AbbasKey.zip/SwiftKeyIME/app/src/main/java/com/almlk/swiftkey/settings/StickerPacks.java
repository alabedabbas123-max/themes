package com.almlk.swiftkey.settings;

/** Built-in text sticker packs shown next to the emoji browser. */
public final class StickerPacks {
  public static final String[] TITLES = {"وجوه نصية", "إسلامية", "زخارف"};

  public static final String[] KAOMOJI = {
    "( ͡° ͜ʖ ͡°)",
    "(╯°□°）╯︵ ┻━┻",
    "ʕ•ᴥ•ʔ",
    "(◕‿◕)",
    "¯\\_(ツ)_/¯",
    "(ಠ_ಠ)",
    "(¬‿¬)",
    "(◕‿◕✿)",
    "(づ｡◕‿‿◕｡)づ",
    "ಥ_ಥ",
    "(≧▽≦)",
    "(；一_一)",
    "♪(´▽｀)",
    "(ﾉ◕ヮ◕)ﾉ",
    "◉‿◉"
  };

  public static final String[] ISLAMIC = {
    "ﷺ",
    "صلى الله عليه وسلم",
    "رضي الله عنه",
    "رضي الله عنها",
    "إن شاء الله",
    "ما شاء الله",
    "الحمد لله",
    "سبحان الله",
    "الله أكبر",
    "جزاك الله خيراً",
    "تقبل الله منا ومنكم",
    "لا إله إلا الله",
    "أستغفر الله",
    "﴿ رَبِّ اشْرَحْ لِي صَدْرِي ﴾"
  };

  public static final String[] DECORATIONS = {
    "★ ☆ ★",
    "♪ ♫ ♪",
    "✿ ❀ ✿",
    "•┈••✦❀✦••┈•",
    "═══ ❁ ═══",
    "▲ ▼ ▲",
    "❝ ❞",
    "« »",
    "‹ ›",
    "╭──╮",
    "(★)",
    "✧･ﾟ"
  };

  private StickerPacks() {}
}
