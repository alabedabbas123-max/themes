# 📚 ثيماتي — توثيق الاستدعاء والوصول للأقسام

> ملف توثيقي شامل يشرح كيفية الوصول لكل أقسام المتجر، واستخدام ملفات الـ JSON،
> وطريقة تحميل العناصر (كلياً أو انتقائياً)، وبنية كل ملف.

---

## 1) بنية المشروع

```
theme-store/
├── firebase.json / .firebaserc        ← إعدادات النشر على Firebase Hosting
├── README.md                          ← نظرة عامة وخطوات النشر
├── API.md                             ← هذا الملف
├── tools/                             ← مولّدات الأصول (أزرار/خلفيات/أيقونات/فهارس)
└── public/                            ← جذر النشر
    ├── index.html                     ← الصفحة الرئيسية
    ├── library.html                   ← المكتبة (كل الأقسام + مركز التحميل)
    ├── library.css / library.js       ← تنسيقات ومنطق المكتبة
    ├── style.css / script.js          ← التنسيقات والتفاعلية العامة
    ├── assets/
    │   ├── data.js                    ← window.LIB (كل البيانات داخل الصفحة)
    │   ├── buttons/btn-<id>.png       ← 193 زراً (448×616)
    │   ├── backgrounds/bg-<id>.jpg    ← 193 خلفية (720×1280)
    │   ├── effects/fx-<id>.png        ← 24 أيقونة تأثير (512×512)
    │   ├── themes-css/theme-<id>.css  ← 193 ملف ثيم CSS
    │   └── saved-themes.json          ← ثيماتك المحفوظة (ممتلكاتي)
    └── downloads/
        ├── json/buttons.json          ← فهرس الأزرار
        ├── json/backgrounds.json      ← فهرس الخلفيات
        ├── json/effects.json          ← فهرس التأثيرات
        ├── json/themes.json           ← كل الثيمات ببياناتها الكاملة
        ├── json/theme-sets.json       ← أقسام الثيمات مجمّعة
        ├── effects/effect-<id>.zip    ← حِزم حركة CSS (8)
        └── thematy-project.zip        ← المشروع كاملاً
```

---

## 2) الروابط العميقة للأقسام (Deep Links)

| القسم | الرابط | الوصف |
|---|---|---|
| الأزرار | `library.html#buttons` | 193 زراً مع فلترة بالمجموعات |
| الخلفيات | `library.html#backgrounds` | 193 خلفية مطابقة 1:1 |
| التفاعلات | `library.html#interactions` | 24 تأثيراً بأيقونات + لوحة تجربة |
| الثيمات | `library.html#themes` | المصمم + ممتلكاتي + ثيمات الأقسام |
| إسلاميات | `library.html#islamic` | 12 ثيم محراب بخلفيات مساجد |
| التحميلات | `library.html#downloads` | مركز التحميل وملفات JSON |
| زر محدد | `library.html#b-<id>` | يمرّر لبطاقة الزر (مثال `#b-jewel-06`) |
| خلفية محددة | `library.html#bg-<id>` | يمرّر لبطاقة الخلفية |
| ثيم محدد | `library.html#theme-<id>` | يمرّر لبطاقة الثيم |
| تأثير محدد | `library.html#fx-<id>` | يمرّر لبطاقة التأثير |

كل قسم فيه زر «🔗 نسخ رابط القسم» لنسخ رابطه الكامل.

---

## 3) ملفات الفهرس JSON وطريقة استخدامها

### 3.1 `downloads/json/buttons.json`
فهرس الأزرار. **القاعدة: جلب القائمة من الملف، وعند اختيار زر يُحمَّل الزر وحده.**

```js
const cat = await (await fetch("downloads/json/buttons.json")).json();
// cat.sets  → [{id:"glossy", ar:"لامع"}, ...]
// cat.items → [{id, set, name, src, palette:{base,dark,light}, bgLum}, ...]

const btn = cat.items.find(b => b.id === "islamic-01");
// تحميل الزر فقط:
const a = Object.assign(document.createElement("a"),
      { href: btn.src, download: `btn-${btn.id}.png` });
a.click();
```

### 3.2 `downloads/json/backgrounds.json`
نفس النمط: `items[].src` مسار الخلفية، و`forButton` يربطها بزرها المطابق.

### 3.3 `downloads/json/effects.json`
فهرس التأثيرات. **عند اختيار تأثير يُحمَّل هو فقط** (أيقونته PNG، وحزمة CSS إن وُجدت):

```js
const fx = await (await fetch("downloads/json/effects.json")).json();
const e  = fx.items.find(x => x.id === "rose");
download(e.icon);              // أيقونة التأثير وحدها
if (e.zip) download(e.zip);    // حزمة حركة CSS اختيارياً
```

### 3.4 `downloads/json/themes.json`
كل ثيم ببياناته الكاملة: الاسم، القسم، الزر المستخدم، الخلفية، ملف CSS،
والألوان المدقّقة (الأساس/الغامق/الفاتح/لون الخط/لون شريط الأدوات).

### 3.5 `downloads/json/theme-sets.json`
**ملف يجمع أقسام الثيمات**: `sets[]` لكل قسم معرفه واسمه العربي وعدد ثيماته
وقائمة ثيماته الكاملة — اختر قسماً فتظهر ثيماته كلها:

```js
const pack = await (await fetch("downloads/json/theme-sets.json")).json();
const sec  = pack.sets.find(s => s.id === "islamic");   // قسم إسلاميات
sec.themes.forEach(t => renderThemeCard(t));            // ثيمات القسم
```

### 3.6 تحميل ثيم كامل (حزمة JSON)
من مركز التحميل ← «أقسام الثيمات» ← اختر قسماً ← اضغط «⬇ تحميل الثيم كاملاً»:
يُنشأ ملف `theme-<id>-bundle.json` يضم: الاسم، القسم، الألوان الخمسة،
ملف CSS نصاً، والخلفية والزر **مضمّنَيْن كـ DataURL** — أي كل بيانات الثيم في ملف واحد.

---

## 4) استخدام ملف ثيم CSS

كل ثيم له `assets/themes-css/theme-<id>.css` بمتغيرات موحّدة مدقّقة التباين:

```css
:root {
  --theme-accent / --theme-accent-dark / --theme-accent-light;
  --theme-text:            /* لون خط المفاتيح المدقّق (WCAG ≥ 3) */
  --theme-toolbar-text:    /* لون شريط الأدوات المدقّق ضد الخلفية */
  --theme-wallpaper: url("../backgrounds/bg-<id>.jpg");
  --theme-keycap:    url("../buttons/btn-<id>.png");
}
```

```html
<link rel="stylesheet" href="assets/themes-css/theme-islamic-01.css" />
<div class="keyboard"><button class="key">ض</button>…</div>
```

---

## 5) ممتلكاتي وتصدير الثيمات المحفوظة

- زر «💾 حفظ الثيم في ممتلكاتي» داخل المصمم يحفظ الثيم محلياً (localStorage).
- زر «⬇ تصدير ملف JSON» ينزّل `saved-themes.json` وبداخله لكل ثيم:
  صورته (DataURL) + اسمه + الأيقونة + الزر + الخط + لون الخط + التاريخ.
- الملف `assets/saved-themes.json` يُقرأ عند الإقلاع ويُدمج مع ممتلكاتك.

---

## 6) النشر

```bash
npm install -g firebase-tools && firebase login
cd theme-store && firebase deploy --only hosting
```

أو انسخ محتوى `public/` لأي استضافة ثابتة. حزمة `downloads/thematy-project.zip`
تضم المشروع كاملاً (الموقع + الأدوات + التوثيق + الفهارس).
