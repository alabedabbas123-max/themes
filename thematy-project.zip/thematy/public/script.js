/* ==========================================================================
   ثيماتي | متجر الثيمات والخلفيات
   ملف التفاعلية الرئيسي — script.js
   يحتوي على:
     1. القائمة المنسدلة للجوال
     2. تأثير شريط التنقل عند التمرير + زر العودة للأعلى
     3. التصفية حسب الفئة (أزرار الفلاتر + بطاقات الفئات)
     4. البحث الفوري في العناصر
     5. التحميل المباشر للموارد + إشعار Toast سلس
     6. عدّاد الإحصائيات المتحرك
     7. تمييز رابط التنقل النشط حسب القسم الظاهر
   ========================================================================== */

"use strict";

/* ننتظر اكتمال تحميل DOM قبل تشغيل أي منطق */
document.addEventListener("DOMContentLoaded", () => {

  /* ---------- مراجع العناصر الرئيسية ---------- */
  const navbar      = document.getElementById("navbar");
  const hamburger   = document.getElementById("hamburger");
  const navLinks    = document.getElementById("navLinks");
  const searchInput = document.getElementById("searchInput");
  const filterBtns  = document.querySelectorAll(".filter-btn");
  const catCards    = document.querySelectorAll(".cat-card");
  const itemCards   = document.querySelectorAll(".item-card");
  const itemsGrid   = document.getElementById("itemsGrid");
  const noResults   = document.getElementById("noResults");
  const resultsCount = document.getElementById("resultsCount");
  const toast       = document.getElementById("toast");
  const toastText   = toast.querySelector(".toast-text");
  const scrollTopBtn = document.getElementById("scrollTop");
  const sectionLinks = document.querySelectorAll(".nav-link");

  /* حالة التصفية الحالية (الفئة + نص البحث) */
  const state = {
    category: "all",
    query: "",
  };

  /* مؤقّت الإشعار لمنع تكراره */
  let toastTimer = null;

  /* ==========================================================================
     1) القائمة المنسدلة للجوال
     ========================================================================== */
  hamburger.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");
    hamburger.classList.toggle("open", isOpen);
    hamburger.setAttribute("aria-expanded", String(isOpen));
  });

  /* إغلاق القائمة عند النقر على أي رابط (تجربة أفضل على الجوال) */
  navLinks.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("open");
      hamburger.classList.remove("open");
      hamburger.setAttribute("aria-expanded", "false");
    });
  });

  /* ==========================================================================
     2) تأثير شريط التنقل + زر العودة للأعلى عند التمرير
     ========================================================================== */
  const onScroll = () => {
    const y = window.scrollY;
    navbar.classList.toggle("scrolled", y > 30);
    scrollTopBtn.classList.toggle("visible", y > 500);
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll(); // تشغيل مرة عند التحميل

  scrollTopBtn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  /* ==========================================================================
     3 + 4) التصفية والبحث — منطق موحّد
     ========================================================================== */

  /**
   * تطبّق حالة التصفية الحالية (الفئة + البحث) على جميع البطاقات،
   * وتحدّث عدّاد النتائج ورسالة "لا توجد نتائج".
   */
  function applyFilters() {
    const q = state.query.trim().toLowerCase();
    let visibleCount = 0;

    itemCards.forEach((card, index) => {
      const matchesCategory =
        state.category === "all" || card.dataset.category === state.category;

      /* البحث يطابق: الاسم + الوسوم + اسم الفئة */
      const haystack = `${card.dataset.name} ${card.dataset.tags} ${card.dataset.category}`.toLowerCase();
      const matchesQuery = q === "" || haystack.includes(q);

      const show = matchesCategory && matchesQuery;
      card.classList.toggle("hidden", !show);

      if (show) {
        visibleCount++;
        /* إعادة تشغيل حركة الدخول بتأخير متدرج جميل */
        card.style.animation = "none";
        void card.offsetWidth; // إعادة تدفق لإجبار إعادة تشغيل الأنيميشن
        card.style.animation = `cardIn 0.45s ease both ${index * 0.05}s`;
      }
    });

    /* تحديث العدّاد ورسالة الفراغ */
    resultsCount.textContent = `عرض ${visibleCount} من ${itemCards.length} عنصر`;
    noResults.hidden = visibleCount !== 0;
  }

  /** تضبط زر الفلتر النشط بصرياً */
  function setActiveFilter(filterValue) {
    filterBtns.forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.filter === filterValue);
    });
  }

  /* النقر على أزرار التصفية */
  filterBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      state.category = btn.dataset.filter;
      setActiveFilter(state.category);
      applyFilters();
    });
  });

  /* النقر على بطاقة فئة يقفز إلى المعرض ويصفّي فوراً */
  catCards.forEach((card) => {
    card.addEventListener("click", () => {
      state.category = card.dataset.filter;
      setActiveFilter(state.category);
      applyFilters();
      document.getElementById("gallery").scrollIntoView({ behavior: "smooth" });
    });
  });

  /* البحث الفوري أثناء الكتابة */
  searchInput.addEventListener("input", () => {
    state.query = searchInput.value;
    applyFilters();
  });

  /* تشغيل أولي لضبط العدّاد */
  applyFilters();

  /* ==========================================================================
     5) التحميل المباشر + إشعار Toast
     ========================================================================== */

  /**
   * تعرض إشعاراً منساباً أسفل الشاشة.
   * @param {string} message نص الرسالة
   * @param {string} icon أيقونة emoji اختيارية
   */
  function showToast(message, icon = "✅") {
    toastText.textContent = message;
    toast.querySelector(".toast-icon").textContent = icon;
    toast.classList.add("show");

    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
  }

  /**
   * تبني ملف SVG من معاينة البطاقة (إن وُجدت) وتنزّله مباشرة،
   * وإلا فتنشئ ملف CSS نموذجي للثيم.
   * ملاحظة: لاستضافة ملفات حقيقية، ضع روابطها في data-href على البطاقة.
   */
  function buildDownload(card) {
    const name = card.dataset.name || "themeati-resource";
    const safeName = name.replace(/\s+/g, "-");

    /* إذا كانت المعاينة تحتوي SVG (الخلفيات) → نزّله كملف مستقل */
    const svg = card.querySelector(".item-preview svg");
    if (svg) {
      const clone = svg.cloneNode(true);
      clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
      clone.setAttribute("width", "1920");
      clone.setAttribute("height", "1248");
      const blob = new Blob([clone.outerHTML], { type: "image/svg+xml" });
      return { url: URL.createObjectURL(blob), filename: `${safeName}.svg` };
    }

    /* غير ذلك (أزرار/أيقونات/ثيمات) → ملف CSS جاهز للاستخدام */
    const css =
`/* ثيماتي — ${name}
   ملف تجريبي جاهز للاستخدام */
.demo {
  border-radius: 18px;
  background: linear-gradient(135deg, #e11d48, #f472b6);
  box-shadow: 0 10px 30px rgba(225, 29, 72, 0.35);
}
`;
    const blob = new Blob([css], { type: "text/css;charset=utf-8" });
    return { url: URL.createObjectURL(blob), filename: `${safeName}.css` };
  }

  /* ربط التحميل بكل الأزرار */
  document.querySelectorAll(".btn-download").forEach((btn) => {
    btn.addEventListener("click", () => {
      const card = btn.closest(".item-card");
      const name = card.dataset.name;

      /* حالة بصرية مؤقتة على الزر */
      btn.classList.add("downloading");
      btn.textContent = "⏳ جارٍ التحميل...";

      /* تأخير بسيط لإظهار الحالة ثم بدء التنزيل */
      setTimeout(() => {
        try {
          const { url, filename } = buildDownload(card);

          /* إنشاء رابط تنزيل برمجي والنقر عليه */
          const a = document.createElement("a");
          a.href = url;
          a.download = filename; // سمة download تضمن التنزيل الفوري
          document.body.appendChild(a);
          a.click();
          a.remove();

          /* تحرير الذاكرة بعد ثانية */
          setTimeout(() => URL.revokeObjectURL(url), 1000);

          showToast(`تم بدء تحميل «${name}» بنجاح! 🎉`, "✅");
        } catch (err) {
          console.error("فشل التحميل:", err);
          showToast("تعذّر بدء التحميل، حاول مجدداً", "⚠️");
        }

        /* إرجاع الزر لحالته الأصلية */
        btn.classList.remove("downloading");
        btn.textContent = "⬇️ تحميل مباشر";
      }, 550);
    });
  });

  /* ==========================================================================
     6) عدّاد الإحصائيات المتحرك (Hero)
     ========================================================================== */
  const counters = document.querySelectorAll(".stat-num");

  /** تحرّك الرقم من 0 إلى قيمته النهائية تدريجياً */
  function animateCounter(el) {
    const target = parseInt(el.dataset.count, 10);
    const duration = 1600; // مدة الحركة بالمللي ثانية
    const start = performance.now();

    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      /* منحنى تباطؤ (easeOut) لحركة أنعم */
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(target * eased).toLocaleString("en-US") + "+";
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  /* تشغيل العدادات عند ظهورها في الشاشة فقط (IntersectionObserver) */
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.6 }
    );
    counters.forEach((c) => io.observe(c));
  } else {
    counters.forEach(animateCounter); // متصفح قديم → شغّل مباشرة
  }

  /* ==========================================================================
     7) تمييز رابط التنقل النشط حسب القسم الظاهر
     ========================================================================== */
  const sections = document.querySelectorAll("section[id], footer[id]");

  if ("IntersectionObserver" in window) {
    const sectionObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.id;
            sectionLinks.forEach((link) => {
              link.classList.toggle("active", link.getAttribute("href") === `#${id}`);
            });
          }
        });
      },
      { rootMargin: "-40% 0px -55% 0px" }
    );
    sections.forEach((s) => sectionObserver.observe(s));
  }

});
