/* ==========================================================================
   مكتبة ثيماتي — library.js
   1) نظام تبويبات: شريط التنقل يعرض قسماً واحداً بكل عناصره عند اختياره
   2) قوائم: الأزرار / الخلفيات / التفاعلات / الثيمات (مع عرض تدريجي كسول)
   3) محرك تفاعلات الضغط (8 تأثيرات) + لوحة تجربة حية
   4) معاينة الثيم كلوحة مفاتيح عربية بتوزيع مطابق (صفوف + أيقونات)
   5) روابط استدعاء عميقة: نسخ رابط القسم + التمرير لأي عنصر عبر الـ hash
   ========================================================================== */
"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const LIB = window.LIB;

  /* ---------- مراجع ---------- */
  const buttonsGrid = document.getElementById("buttonsGrid");
  const backgroundsGrid = document.getElementById("backgroundsGrid");
  const fxGrid = document.getElementById("fxGrid");
  const perButtonGrid = document.getElementById("perButtonGrid");
  const setChips = document.getElementById("setChips");
  const playKbd = document.getElementById("playKbd");
  const activeFxName = document.getElementById("activeFxName");
  const toast = document.getElementById("toast");
  const toastText = toast.querySelector(".toast-text");
  const subnavLinks = document.querySelectorAll(".subnav-link");

  const SECTIONS = ["buttons", "backgrounds", "interactions", "themes", "islamic", "downloads"];
  let toastTimer = null;
  let activeFx = "ripple";

  function showToast(msg, icon = "✅") {
    toastText.textContent = msg;
    toast.querySelector(".toast-icon").textContent = icon;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
  }

  /* ======================================================================
     1) نظام التبويبات — اختيار قسم يعرض كل عناصره ويخفي البقية
     ====================================================================== */
  function showSection(id, scroll = true) {
    SECTIONS.forEach((s) => document.getElementById(s).classList.toggle("active", s === id));
    subnavLinks.forEach((l) => l.classList.toggle("current", l.getAttribute("href") === "#" + id));
    if (scroll) {
      setTimeout(() => {
        const y = document.getElementById(id).getBoundingClientRect().top + window.scrollY - 118;
        window.scrollTo({ top: Math.max(y, 0), behavior: "smooth" });
      }, 40);
    }
  }

  function sectionOf(hash) {
    const h = (hash || "").replace("#", "");
    if (SECTIONS.includes(h)) return h;
    if (h.startsWith("bg-")) return "backgrounds";
    if (h.startsWith("b-")) return "buttons";
    if (h.startsWith("fx-")) return "interactions";
    if (h.startsWith("theme-")) return "themes";
    return null;
  }

  function route() {
    const sec = sectionOf(location.hash);
    if (!sec) { showSection("buttons", false); return; }
    showSection(sec, false);
    const h = location.hash;
    setTimeout(() => {
      if (h.length > 1 && !SECTIONS.includes(h.replace("#", ""))) {
        const el = document.querySelector(h);
        if (el) { el.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
      }
      const y = document.getElementById(sec).getBoundingClientRect().top + window.scrollY - 118;
      window.scrollTo({ top: Math.max(y, 0), behavior: "smooth" });
    }, 70);
  }

  /* كل الروابط الداخلية تمر عبر الموجّه (تبديل تبويب + تمرير) */
  document.addEventListener("click", (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    e.preventDefault();
    const h = a.getAttribute("href");
    if (location.hash === h) route();
    else location.hash = h;
  });
  window.addEventListener("hashchange", route);

  /* ======================================================================
     2) عرض تدريجي كسول (كل عناصر القسم تُعرض دفعات عند التمرير)
     ====================================================================== */
  function lazyGrid(container, items, render, batch = 24) {
    container.innerHTML = "";
    let i = 0;
    const sent = document.createElement("div");
    sent.className = "sentinel";
    function push() {
      const wrap = document.createElement("div");
      wrap.className = "batch";
      wrap.innerHTML = items.slice(i, i + batch).map(render).join("");
      while (wrap.firstChild) container.appendChild(wrap.firstChild);
      i += batch;
    }
    push();
    container.appendChild(sent);
    const io = new IntersectionObserver((es) => {
      if (es.some((en) => en.isIntersecting) && i < items.length) {
        push();
        if (i >= items.length) io.disconnect();
      }
    }, { rootMargin: "800px" });
    io.observe(sent);
  }

  /* ======================================================================
     3) قائمة الأزرار
     ====================================================================== */
  function buttonCard(b) {
    return `
    <article class="lib-card" id="b-${b.id}">
      <div class="prev"><img src="${b.src}" alt="زر ${b.name}" loading="lazy" /></div>
      <div class="body">
        <h3 class="name">${b.name}</h3>
        <div class="tags">
          <span class="tag">${b.setAr}</span>
          <span class="tag color">${b.colorAr}</span>
        </div>
        <div class="actions">
          <a class="mini-btn" href="${b.src}" download="btn-${b.id}.png">⬇️ تحميل الزر</a>
          <a class="mini-btn alt" href="#bg-${b.id}" title="الخلفية المطابقة">🖼️ خلفيته</a>
        </div>
      </div>
    </article>`;
  }

  function renderButtons(filterSet = "all") {
    const list = filterSet === "all" ? LIB.buttons : LIB.buttons.filter((b) => b.set === filterSet);
    lazyGrid(buttonsGrid, list, buttonCard);
  }

  setChips.innerHTML =
    `<button class="chip active" data-set="all">الكل (${LIB.buttons.length})</button>` +
    LIB.sets.map((s) => {
      const n = LIB.buttons.filter((b) => b.set === s.id).length;
      return `<button class="chip" data-set="${s.id}">${s.ar} (${n})</button>`;
    }).join("");

  setChips.addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    setChips.querySelectorAll(".chip").forEach((c) => c.classList.toggle("active", c === chip));
    renderButtons(chip.dataset.set);
  });

  renderButtons();

  /* ======================================================================
     4) قائمة الخلفيات
     ====================================================================== */
  function bgCard(g) {
    return `
    <article class="lib-card bg-card" id="bg-${g.id}">
      <div class="prev"><img src="${g.src}" alt="خلفية ${g.name}" loading="lazy" /></div>
      <div class="body">
        <h3 class="name">${g.name}</h3>
        <div class="actions">
          <a class="mini-btn" href="${g.src}" download="bg-${g.id}.jpg">⬇️ تحميل الخلفية</a>
          <a class="mini-btn alt" href="#b-${g.forButton}" title="الزر المطابق">🔘 زرّها</a>
        </div>
      </div>
    </article>`;
  }
  lazyGrid(backgroundsGrid, LIB.backgrounds, bgCard);

  document.getElementById("libCount").textContent =
    `${LIB.buttons.length} زراً · ${LIB.backgrounds.length} خلفية · ${LIB.effects.length} تفاعلات · ${LIB.buttons.length} ثيم`;

  /* ======================================================================
     5) محرك تفاعلات الضغط + لوحة التجربة
     ====================================================================== */
  function playEffect(key, fx, ev) {
    const rect = key.getBoundingClientRect();
    const cx = ev && ev.clientX ? ev.clientX - rect.left : rect.width / 2;
    const cy = ev && ev.clientY ? ev.clientY - rect.top : rect.height / 2;
    switch (fx) {
      case "ripple": {
        const s = Math.max(rect.width, rect.height);
        const r = document.createElement("span");
        r.className = "fx-ripple";
        r.style.width = r.style.height = s + "px";
        r.style.left = cx - s / 2 + "px";
        r.style.top = cy - s / 2 + "px";
        key.appendChild(r);
        key.classList.add("fx-clip");
        setTimeout(() => { r.remove(); key.classList.remove("fx-clip"); }, 650);
        break;
      }
      case "glow": case "bounce": case "neon":
        key.classList.remove("fx-" + fx); void key.offsetWidth; key.classList.add("fx-" + fx);
        break;
      case "wave":
        key.classList.remove("fx-wave"); void key.offsetWidth;
        key.classList.add("fx-wave", "fx-clip");
        setTimeout(() => key.classList.remove("fx-wave", "fx-clip"), 600);
        break;
      case "sink":
        key.classList.add("fx-sink");
        setTimeout(() => key.classList.remove("fx-sink"), 180);
        break;
      case "sparkle":
        for (let i = 0; i < 8; i++) {
          const sp = document.createElement("span");
          sp.className = "fx-spark";
          const a = Math.random() * Math.PI * 2, d = 30 + Math.random() * 30;
          sp.style.left = "50%"; sp.style.top = "50%";
          sp.style.setProperty("--dx", Math.cos(a) * d + "px");
          sp.style.setProperty("--dy", Math.sin(a) * d + "px");
          key.appendChild(sp);
          setTimeout(() => sp.remove(), 750);
        }
        break;
      case "bubbles":
        for (let i = 0; i < 5; i++) {
          const b = document.createElement("span");
          b.className = "fx-bub";
          const s = 6 + Math.random() * 10;
          b.style.width = b.style.height = s + "px";
          b.style.left = 15 + Math.random() * 70 + "%";
          b.style.animationDelay = Math.random() * 0.25 + "s";
          key.appendChild(b);
          setTimeout(() => b.remove(), 1200);
        }
        break;
    }
  }

  const LETTERS = "ضصثقفغعهخحجشسيبلاتنمكط".split("");
  playKbd.innerHTML =
    LETTERS.map((l) => `<button class="key tkey" type="button">${l}</button>`).join("") +
    `<button class="key tkey wide" type="button">مسافة</button>`;
  playKbd.addEventListener("pointerdown", (e) => {
    const k = e.target.closest(".tkey");
    if (k) playEffect(k, activeFx, e);
  });

  /* بطاقات التفاعلات: أيقونة مولّدة + وصف + تحميل (24 تأثيراً) */
  function fxCard(fx) {
    return `
    <article class="fx-card" id="fx-${fx.id}" data-css="${fx.css || ""}">
      <div class="fx-prev"><img src="${fx.icon}" alt="أيقونة تأثير ${fx.name}" loading="lazy" /></div>
      <div class="fx-head">
        <h3>${fx.name}</h3>
        <span class="tag color">${fx.tag}</span>
      </div>
      <p>${fx.desc}</p>
      <div class="actions">
        ${fx.css ? `<button class="mini-btn alt apply-fx" data-fx="${fx.css}" type="button">⌨️ تطبيق حي</button>` : ""}
        <a class="mini-btn" href="${fx.icon}" download="effect-${fx.id}.png">⬇️ الأيقونة</a>
        ${fx.zip ? `<a class="mini-btn alt" href="${fx.zip}" download="effect-${fx.css}.zip">🎁 حزمة CSS</a>` : ""}
      </div>
    </article>`;
  }
  lazyGrid(fxGrid, LIB.effects, fxCard, 24);

  fxGrid.addEventListener("click", (e) => {
    const apply = e.target.closest(".apply-fx");
    if (!apply) return;
    activeFx = apply.dataset.fx;
    const fx = LIB.effects.find((f) => (f.css || f.id) === activeFx);
    activeFxName.textContent = fx.name;
    fxGrid.querySelectorAll(".fx-card").forEach((c) => c.classList.toggle("active", c.dataset.css === activeFx));
    showToast(`تم تفعيل تأثير «${fx.name}» على لوحة التجربة`, "⌨️");
    playKbd.scrollIntoView({ behavior: "smooth", block: "center" });
  });

  /* ======================================================================
     6) الثيمات — كل ثيم بزر واحد فوق كيبورد مطابق للصورة (أيقونات SVG)
     ====================================================================== */
  const KBD_R1 = ["ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د"];
  const KBD_R1_TOP = ["ً", "ٍ", "ٌ", "ْ", "5", "6", "7", "8", "9", "0", "ـ", "="];
  const KBD_R2 = ["ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ذ"];
  const KBD_R3 = ["ئ", "ء", "ؤ", "ر", "ى", "ة", "و", "ز", "ط", "ظ"];
  const KBD_SUGG = ["وبركاته", "الله", "السلام"]; /* الترتيب البصري اليسار→اليمين كما في الجهاز */

  /* أيقونات SVG متجهية (بدل الإيموجي) */
  const ICON = {
    backspace: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M9 5h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9L2 12z"/><path d="M11 9.5l5 5M16 9.5l-5 5"/></svg>',
    enter: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 5v9a2 2 0 0 1-2 2H9"/><path d="M12.5 12.5L9 16l3.5 3.5"/></svg>',
    smile: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8.5 14s1.3 2 3.5 2 3.5-2 3.5-2" stroke-linecap="round"/><circle cx="9" cy="10" r=".9" fill="currentColor"/><circle cx="15" cy="10" r=".9" fill="currentColor"/></svg>',
    clip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="5" width="12" height="16" rx="2"/><path d="M9 5V3.5h6V5"/><path d="M9 10h6M9 14h6"/></svg>',
    chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 9.5l6 6 6-6"/></svg>',
    mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
    gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1"/></svg>',
    globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18z"/></svg>',
    kbd: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2.5" y="6" width="19" height="12" rx="2.5"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M6 14h.01M18 14h.01M9 14h6"/></svg>',
    expand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
    dots: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>',
  };

  /** نظام تدقيق التباين: لون خط مدقّق ضد لوحة الزر وضد الخلفية (نسبة WCAG ≥ 3) */
  function textVars(pal, bgLum) {
    const rgb = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16));
    const hx = (a) => "#" + a.map((c) => Math.max(0, Math.min(255, c)).toString(16).padStart(2, "0")).join("");
    const rel = (c) => {
      const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
      return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
    };
    const ratio = (a, b) => { const l1 = rel(a), l2 = rel(b); return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05); };
    const base = rgb(pal.base), dark = rgb(pal.dark), light = rgb(pal.light);
    const panel = base.map((c) => Math.round(c + (255 - c) * 0.43));      // لون لوحة المفتاح
    const pl = 0.299 * panel[0] + 0.587 * panel[1] + 0.114 * panel[2];
    /* 1) خط المفاتيح: درجة من عائلة الثيم ثم تدقيق ضد لوحة المفتاح */
    let kc = pl > 150 ? dark : light.map((c) => Math.round(c + (255 - c) * 0.45));
    if (ratio(kc, panel) < 3) kc = pl > 150 ? [20, 16, 24] : [255, 255, 255];
    const kcShadow = pl > 150 ? "0 1px 2px rgba(255,255,255,.65)" : "0 1px 3px rgba(0,0,0,.9),0 0 5px rgba(0,0,0,.55)";
    /* 2) لون شريط الأدوات: مدقّق ضد سطوع الخلفية الفعلي (مع الحجاب) */
    const eff = (bgLum == null ? 120 : bgLum) * 0.7 + 12 * 0.3;
    const approx = eff > 140 ? [235, 235, 235] : [22, 18, 26];
    let bar = eff > 140 ? dark : light.map((c) => Math.round(c + (255 - c) * 0.5));
    if (ratio(bar, approx) < 3) bar = eff > 140 ? [26, 20, 30] : [255, 255, 255];
    const barShadow = eff > 140 ? "0 1px 2px rgba(255,255,255,.55)" : "0 1px 3px rgba(0,0,0,.85)";
    return {
      cls: pl > 150 ? "txt-dark" : "txt-light",
      text: hx(kc), shadow: kcShadow,
      bar: hx(bar), barShadow,
    };
  }

  /** استدعاء الثيم يجلب معاً: خلفية الكيبورد + خلفية الزر + لون الخط */
  function kbdMock(btn) {
    const src = btn.src;
    const tv = textVars(btn.palette, btn.bgLum);
    const wall = `assets/backgrounds/bg-${btn.id}.jpg`;
    const cap = (label, top = "") =>
      `<span class="kcap" style="background-image:url('${src}')">${top ? `<i>${top}</i>` : ""}<b>${label}</b></span>`;
    const sp = (inner, cls = "") =>
      `<span class="kcap sp ${cls}" style="background-image:url('${src}')">${inner}</span>`;
    return `<div class="kbd-mock ${tv.cls}" style="background-image:url('${wall}');--kc-text:${tv.text};--kc-shadow:${tv.shadow};--kb-text:${tv.bar};--kb-shadow:${tv.barShadow};">
      <div class="kb-toolbar">${["dots", "expand", "kbd", "mic", "globe", "clip", "gear"].map((k) => `<span class="tb-ico">${ICON[k]}</span>`).join("")}</div>
      <div class="krow sugg-row">${KBD_SUGG.map((s) => `<span class="sugg" style="background-image:url('${src}')">${s}</span>`).join("")}<span class="sugg-key" style="background-image:url('${src}')">${ICON.chev}</span></div>
      <div class="krow">${KBD_R1.map((l, i) => cap(l, KBD_R1_TOP[i])).join("")}</div>
      <div class="krow ind1">${KBD_R2.map((l) => cap(l)).join("")}</div>
      <div class="krow">${KBD_R3.map((l) => cap(l)).join("")}${sp(ICON.backspace, "wide del")}</div>
      <div class="krow">${sp("<b>123</b>", "w1")}${sp(ICON.smile)}${sp(`<i class="top-ico">${ICON.clip}</i><b>،</b>`)}<span class="kcap sp space" style="background-image:url('${src}')"><b>العربية</b></span>${sp("<i>!</i><b>.</b>")}${sp(ICON.enter, "enter")}</div>
    </div>`;
  }

  /* كل ثيم = زر واحد فقط */
  function themeCard(b) {
    return `
    <article class="theme-card" id="theme-${b.id}">
      <div class="theme-prev" style="background-image:url('assets/backgrounds/bg-${b.id}.jpg')">
        <span class="theme-name">ثيم ${b.name}</span>
        ${kbdMock(b)}
      </div>
      <div class="theme-body">
        <p>ثيم بزر واحد: كل أغطية المفاتيح من الزر نفسه فوق خلفيته المطابقة.</p>
        <span class="theme-meta">📦 3 ملفات: زر PNG + خلفية JPG + theme.css</span>
        <div class="actions actions-3">
          <a class="mini-btn" href="${b.src}" download="btn-${b.id}.png">⬇️ الزر</a>
          <a class="mini-btn" href="assets/backgrounds/bg-${b.id}.jpg" download="bg-${b.id}.jpg">🖼️ الخلفية</a>
          <a class="mini-btn alt" href="${b.css}" download="theme-${b.id}.css">🎨 CSS</a>
        </div>
      </div>
    </article>`;
  }

  /* عرض الثيمات يتم عبر renderThemes أدناه (فلترة حسب المجموعة) */

  /* ---------- مصمم الكيبورد: تطبيق الزر على كل المفاتيح ---------- */
  const dSet = document.getElementById("dSet");
  const dBtn = document.getElementById("dBtn");
  const dKbd = document.getElementById("designerKbd");
  const dScreen = document.getElementById("designerScreen");
  const dName = document.getElementById("dName");
  const dDlBtn = document.getElementById("dDlBtn");
  const dDlBg = document.getElementById("dDlBg");
  const dDlCss = document.getElementById("dDlCss");
  let dCurrent = LIB.buttons[0];

  dSet.innerHTML = LIB.sets.map((s) => `<option value="${s.id}">${s.ar}</option>`).join("");
  function fillBtnSelect() {
    if (!dSet.value) dSet.value = LIB.sets[0].id;   // ضمان اختيار أول مجموعة دائماً
    const list = LIB.buttons.filter((b) => b.set === dSet.value);
    dBtn.innerHTML = list.map((b) => `<option value="${b.id}">${b.name}</option>`).join("");
    if (!dBtn.value && list[0]) dBtn.value = list[0].id; // ضمان اختيار أول زر
  }
  function applyDesigner(btn) {
    dCurrent = btn || LIB.buttons[0];
    btn = dCurrent;
    dKbd.innerHTML = kbdMock(btn);                 // الخلفية + الزر + لون الخط معاً
    dScreen.style.backgroundImage = `url('assets/backgrounds/bg-${btn.id}.jpg')`;
    dName.textContent = `الثيم المطبق: ${btn.name}`;
    dDlBtn.href = btn.src; dDlBtn.setAttribute("download", `btn-${btn.id}.png`);
    dDlBg.href = `assets/backgrounds/bg-${btn.id}.jpg`; dDlBg.setAttribute("download", `bg-${btn.id}.jpg`);
    dDlCss.href = btn.css; dDlCss.setAttribute("download", `theme-${btn.id}.css`);
  }
  function syncSelects() { dSet.value = dCurrent.set; fillBtnSelect(); dBtn.value = dCurrent.id; }
  dSet.addEventListener("change", () => {
    fillBtnSelect();
    applyDesigner(LIB.buttons.find((b) => b.id === dBtn.value));
    renderThemes(dSet.value);          // الثيمات المعروضة تتبع المجموعة المختارة
  });
  dBtn.addEventListener("change", () => applyDesigner(LIB.buttons.find((b) => b.id === dBtn.value)));
  function step(dir) {
    const i = LIB.buttons.indexOf(dCurrent);
    applyDesigner(LIB.buttons[(i + dir + LIB.buttons.length) % LIB.buttons.length]);
    syncSelects();
  }
  document.getElementById("dPrev").addEventListener("click", () => step(-1));
  document.getElementById("dNext").addEventListener("click", () => step(1));
  fillBtnSelect();
  applyDesigner(LIB.buttons[0]);

  /* ---------- ممتلكاتي: حفظ الثيم + تصدير ملف JSON ---------- */
  const savedGrid = document.getElementById("savedGrid");
  const savedCount = document.getElementById("savedCount");
  const dSave = document.getElementById("dSave");
  const dExport = document.getElementById("dExport");
  const dHint = document.getElementById("dHint");
  const STORE_KEY = "thematy_saved_themes";
  const FONT_USED = (getComputedStyle(document.body).fontFamily || "Tajawal").split(",")[0].replace(/["']/g, "").trim();
  const loadSaved = () => { try { return JSON.parse(localStorage.getItem(STORE_KEY)) || []; } catch (e) { return []; } };
  let fileThemes = [];   /*themes القادمة من ملف saved-themes.json*/

  /** بطاقة الثيم المحفوظ: صورة الكيبورد كاملة (خلفية + زر + خط) */
  function savedEntry(btn) {
    return {
      id: btn.id,
      name: `ثيم ${btn.name}`,
      savedAt: new Date().toISOString(),
      image: `assets/backgrounds/bg-${btn.id}.jpg`,          /* صورة الثيم/الخلفية */
      keyboardImage: `assets/buttons/btn-${btn.id}.png`,     /* صورة الزر على المفاتيح */
      icon: (LIB.sets.find((s) => s.id === btn.set) || {}).ar || btn.set, /* الأيقونة المستخدمة */
      button: btn.name,                                       /* الزر المستخدم */
      font: FONT_USED,                                        /* الخط المستخدم */
      textColor: textVars(btn.palette, btn.bgLum).text,        /* لون الخط المدقّق */
    };
  }
  function renderSaved() {
    const local = loadSaved();
    const all = local.concat(fileThemes.filter((t) => !local.some((l) => l.id === t.id)));
    savedCount.textContent = all.length;
    savedGrid.innerHTML = all.length
      ? all.map((t) => {
          const btn = LIB.buttons.find((b) => b.id === t.id);
          return `<article class="saved-card">
            ${btn ? kbdMock(btn) : `<div class="saved-prev" style="background-image:url('${t.image}')"></div>`}
            <div class="saved-meta">
              <b>${t.name}</b>
              <span>الزر: ${t.button} • الأيقونة: ${t.icon} • الخط: ${t.font}</span>
              <div class="saved-actions">
                <a class="chip" href="${t.image}" download>🖼️ الخلفية</a>
                <a class="chip" href="${t.keyboardImage}" download>⬇️ الزر</a>
                <button class="chip danger" type="button" data-del="${t.id}">🗑️ حذف</button>
              </div>
            </div>
          </article>`;
        }).join("")
      : `<p class="empty-note">لا توجد ثيمات محفوظة بعد —عاين ثيمًا في المصمم ثم اضغط «💾 حفظ الثيم في ممتلكاتي».</p>`;
  }
  savedGrid.addEventListener("click", (e) => {
    const d = e.target.closest("[data-del]");
    if (!d) return;
    localStorage.setItem(STORE_KEY, JSON.stringify(loadSaved().filter((t) => t.id !== d.dataset.del)));
    renderSaved();
  });
  dSave.addEventListener("click", () => {
    const list = loadSaved();
    if (list.some((t) => t.id === dCurrent.id)) { dHint.textContent = "هذا الثيم محفوظ بالفعل في ممتلكاتك ✓"; return; }
    list.unshift(savedEntry(dCurrent));
    localStorage.setItem(STORE_KEY, JSON.stringify(list));
    renderSaved();
    dHint.textContent = `تم حفظ «${dCurrent.name}» في ممتلكاتك ✓ — صدّره من زر تصدير JSON`;
  });
  /** تضمين صورة الثيم داخل ملف JSON كـ DataURL */
  const toData = (url) => fetch(url).then((r) => r.blob()).then((b) => new Promise((res) => {
    const f = new FileReader(); f.onload = () => res(f.result); f.readAsDataURL(b);
  }));
  dExport.addEventListener("click", async () => {
    const local = loadSaved();
    if (!local.length) { dHint.textContent = "احفظ ثيمًا واحدًا على الأقل قبل التصدير."; return; }
    dHint.textContent = "جارٍ تجهيز ملف JSON بصور الثيمات المضمّنة…";
    const themes = [];
    for (const t of local) {
      themes.push(Object.assign({}, t, {
        imageData: await toData(t.image),             /* صورة الثيم/الكيبورد مضمّنة */
        buttonImageData: await toData(t.keyboardImage), /* صورة الزر مضمّنة */
      }));
    }
    const payload = { app: "ثيماتي", kind: "saved-themes", version: 2, exportedAt: new Date().toISOString(), font: FONT_USED, themes };
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
    a.download = "saved-themes.json";
    a.click();
    URL.revokeObjectURL(a.href);
    dHint.textContent = "تم تصدير saved-themes.json — يشمل صورة كل ثيم واسمه وأيقونته وزره وخطه ✓";
  });
  fetch("assets/saved-themes.json")
    .then((r) => (r.ok ? r.json() : null))
    .then((j) => { fileThemes = (j && j.themes) || []; renderSaved(); })
    .catch(() => renderSaved());
  renderSaved();

  /* ---------- تبديل أقسام الثيمات: كل الثيمات المعروضة تتبع المجموعة ---------- */
  const themeSetChips = document.getElementById("themeSetChips");
  function renderThemes(filterSet = "all") {
    const list = filterSet === "all" ? LIB.buttons : LIB.buttons.filter((b) => b.set === filterSet);
    lazyGrid(perButtonGrid, list, themeCard, 12);   // كل أزرار القسم تُعرض بتصميمها
    document.getElementById("perBtnCount").textContent = list.length + " ثيم";
    themeSetChips.querySelectorAll(".chip").forEach((c) => c.classList.toggle("active", c.dataset.set === filterSet));
  }
  themeSetChips.innerHTML =
    `<button class="chip active" data-set="all" type="button">الكل (${LIB.buttons.length})</button>` +
    LIB.sets.map((s) => `<button class="chip" data-set="${s.id}" type="button">${s.ar}</button>`).join("");
  themeSetChips.addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    renderThemes(chip.dataset.set);
    if (chip.dataset.set !== "all") {   // مزامنة المصمم مع القسم المختار
      dSet.value = chip.dataset.set;
      fillBtnSelect();
      applyDesigner(LIB.buttons.find((b) => b.id === dBtn.value));
    }
  });
  renderThemes("all");

  /* ---------- قسم التصاميم الإسلامية: ثيمات المحارب كاملة ---------- */
  const islamicGrid = document.getElementById("islamicGrid");
  const islamicList = LIB.buttons.filter((b) => b.set === "islamic");
  document.getElementById("islamicCount").textContent = islamicList.length + " تصميماً";
  lazyGrid(islamicGrid, islamicList, themeCard, 12);

  /* ======================================================================
     8) مركز التحميل: فهارس JSON + تحميل انتقائي + حزمة الثيم الكاملة
     ====================================================================== */
  const dl = (href, name) => { const a = document.createElement("a"); a.href = href; a.download = name; a.click(); };

  /* بطاقات ملفات الفهرس */
  const JSON_CATS = [
    ["downloads/json/buttons.json", "buttons.json", "فهرس 193 زراً: المعرف، المجموعة، اللون، المسار، اللوحة، سطوع الخلفية — اختر زراً حمّله وحده"],
    ["downloads/json/backgrounds.json", "backgrounds.json", "فهرس 193 خلفية مطابقة 1:1 مع ربط كل خلفية بزرها"],
    ["downloads/json/effects.json", "effects.json", "فهرس 24 تأثيراً: الأيقونة والوسم والوصف وحزمة CSS إن وجدت — اختر تأثيراً حمّله وحده"],
    ["downloads/json/themes.json", "themes.json", "كل الثيمات: الاسم، القسم، الزر، الخلفية، CSS، والألوان المدقّقة"],
    ["downloads/json/theme-sets.json", "theme-sets.json", "أقسام الثيمات مجمّعة — اختر قسماً تظهر ثيماته كاملة ببياناتها"],
    ["assets/saved-themes.json", "saved-themes.json", "ملف ممتلكاتي: الثيمات المحفوظة بصورها وبياناتها"],
  ];
  document.getElementById("jsonGrid").innerHTML = JSON_CATS.map(([href, name, desc]) => `
    <article class="saved-card"><div class="saved-meta">
      <b>📄 ${name}</b><span>${desc}</span>
      <div class="saved-actions"><a class="chip" href="${href}" download>⬇ تحميل الملف</a></div>
    </div></article>`).join("");

  /* الأزرار: جلب الفهرس ثم تحميل الزر المختار فقط */
  const dlSet = document.getElementById("dlSet"), dlBtn = document.getElementById("dlBtn");
  const dlBtnImg = document.getElementById("dlBtnImg"), dlBtnDl = document.getElementById("dlBtnDl");
  let btnCat = null;
  document.getElementById("btnFetch").addEventListener("click", async () => {
    btnCat = await (await fetch("downloads/json/buttons.json")).json();
    dlSet.innerHTML = btnCat.sets.map((s) => `<option value="${s.id}">${s.ar}</option>`).join("");
    const fill = () => {
      const list = btnCat.items.filter((b) => b.set === dlSet.value);
      dlBtn.innerHTML = list.map((b) => `<option value="${b.id}">${b.name}</option>`).join("");
      pick();
    };
    const pick = () => {
      const b = btnCat.items.find((x) => x.id === dlBtn.value);
      if (!b) return;
      dlBtnImg.src = b.src;
      dlBtnDl.href = b.src;
      dlBtnDl.setAttribute("download", `btn-${b.id}.png`);
      dlBtnDl.textContent = `⬇ تحميل «${b.name}» فقط`;
    };
    dlSet.onchange = fill; dlBtn.onchange = pick;
    fill();
    showToast("تم جلب فهرس الأزرار من buttons.json", "📥");
  });

  /* التأثيرات: جلب الفهرس ثم تحميل التأثير المختار فقط */
  document.getElementById("fxFetch").addEventListener("click", async () => {
    const cat = await (await fetch("downloads/json/effects.json")).json();
    document.getElementById("fxDlRow").innerHTML = cat.items.map((e) => `
      <article class="saved-card">
        <div class="fx-prev"><img src="${e.icon}" alt="${e.name}" loading="lazy" /></div>
        <div class="saved-meta"><b>${e.name}</b><span>${e.tag} — ${e.desc}</span>
          <div class="saved-actions">
            <a class="chip" href="${e.icon}" download="effect-${e.id}.png">⬇ الأيقونة فقط</a>
            ${e.zip ? `<a class="chip" href="${e.zip}" download="effect-${e.css}.zip">🎁 حزمة CSS</a>` : ""}
          </div>
        </div>
      </article>`).join("");
    showToast("تم جلب فهرس التأثيرات من effects.json", "📥");
  });

  /* أقسام الثيمات: اختيار قسم → ثيماته + تحميل الثيم كاملاً ببياناته */
  const dlThemeSet = document.getElementById("dlThemeSet"), dlThemesGrid = document.getElementById("dlThemesGrid");
  let setsPack = null;
  document.getElementById("setsFetch").addEventListener("click", async () => {
    setsPack = await (await fetch("downloads/json/theme-sets.json")).json();
    dlThemeSet.innerHTML = setsPack.sets.map((s) => `<option value="${s.id}">${s.ar} (${s.count})</option>`).join("");
    const show = () => {
      const sec = setsPack.sets.find((s) => s.id === dlThemeSet.value);
      dlThemesGrid.innerHTML = sec.themes.map((t) => `
        <article class="saved-card">
          <div class="fx-prev"><img src="${t.button.src}" alt="${t.name}" loading="lazy" /></div>
          <div class="saved-meta"><b>${t.name}</b>
            <span>الزر: ${t.button.name} • الخط: ${t.colors.text} • الشريط: ${t.colors.toolbarText}</span>
            <div class="saved-actions">
              <button class="chip save-chip" type="button" data-bundle="${t.id}">⬇ تحميل الثيم كاملاً (JSON)</button>
              <a class="chip" href="${t.background.src}" download>🖼️ الخلفية</a>
              <a class="chip" href="${t.button.src}" download>🔘 الزر</a>
            </div>
          </div>
        </article>`).join("");
    };
    dlThemeSet.onchange = show;
    show();
    showToast("تم جلب أقسام الثيمات من theme-sets.json", "📥");
  });
  dlThemesGrid.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-bundle]");
    if (!b || !setsPack) return;
    const t = setsPack.sets.flatMap((s) => s.themes).find((x) => x.id === b.dataset.bundle);
    showToast("جارٍ تجهيز حزمة الثيم الكاملة…", "");
    const [cssText, bgData, btnData] = await Promise.all([
      fetch(t.css).then((r) => r.text()), toData(t.background.src), toData(t.button.src),
    ]);
    const bundle = {
      app: "ثيماتي", kind: "theme-bundle", version: 2,
      id: t.id, name: t.name, set: t.set, setAr: t.setAr,
      colors: t.colors,
      button: { name: t.button.name, src: t.button.src, imageData: btnData },
      background: { src: t.background.src, imageData: bgData },
      cssFile: t.css, cssText,
      exportedAt: new Date().toISOString(),
    };
    dl(URL.createObjectURL(new Blob([JSON.stringify(bundle, null, 2)], { type: "application/json" })),
       `theme-${t.id}-bundle.json`);
    showToast(`تم تحميل حزمة «${t.name}» كاملة`, "✅");
  });

  /* ======================================================================
     7) نسخ روابط الأقسام
     ====================================================================== */
  document.querySelectorAll(".copy-link").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const url = `${location.origin}${location.pathname}#${btn.dataset.section}`;
      try {
        await navigator.clipboard.writeText(url);
        showToast("تم نسخ رابط القسم: " + url, "🔗");
      } catch {
        showToast("الرابط: " + url, "🔗");
      }
    });
  });

  /* ---------- قائمة الجوال ---------- */
  const hamburger = document.getElementById("hamburger");
  const navLinks = document.getElementById("navLinks");
  hamburger.addEventListener("click", () => {
    const open = navLinks.classList.toggle("open");
    hamburger.classList.toggle("open", open);
    hamburger.setAttribute("aria-expanded", String(open));
  });
  navLinks.querySelectorAll(".nav-link").forEach((l) =>
    l.addEventListener("click", () => navLinks.classList.remove("open")));

  /* ---------- التوجيه الأولي حسب الـ hash ---------- */
  route();
});
