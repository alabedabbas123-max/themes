# -*- coding: utf-8 -*-
"""
أداة بناء "مكتبة ثيماتي"
------------------------
1) تقطيع شبكات الأزرار (الصور المرفقة + الأوراق المولّدة) إلى ملفات PNG شفافة منفصلة.
2) استخراج لوحة اللون لكل زر وتوليد خلفية JPG مطابقة لكل زر (بنفس العدد).
3) بناء حِزم ثيمات ZIP (أزرار + خلفية + theme.css).
4) بناء حِزم تفاعلات ZIP (effect.css + effect.js) لتأثيرات الضغط على المفاتيح.
5) إصدار public/assets/data.js ببيانات المكتبة كاملة.
"""
import os, json, random, colorsys, zipfile
from collections import deque
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = "/home/user/theme-store"
PUB  = os.path.join(ROOT, "public")
BTN  = os.path.join(PUB, "assets", "buttons")
BGD  = os.path.join(PUB, "assets", "backgrounds")
DLTH = os.path.join(PUB, "downloads", "themes")
DLFX = os.path.join(PUB, "downloads", "effects")
for d in (BTN, BGD, DLTH, DLFX):
    os.makedirs(d, exist_ok=True)

# ---------------------------------------------------------------- مصادر الشبكات
SOURCES = [
    # (المسار، اسم المجموعة، خلفية الملّون)
    ("/home/user/uploads/copilot_image_1790357734676.png", "glossy",  "لامع"),
    ("/home/user/uploads/copilot_image_1790358786511.png", "jewel",   "مجوهرات ملكية"),
    ("/home/user/uploads/copilot_image_1790358376260.png", "frame",   "إطار أنيق"),
    (os.path.join(ROOT, "tools/sheet_frames_a.png"),       "newframe-a", "إطارات فاخرة أ"),
    (os.path.join(ROOT, "tools/sheet_frames_b.png"),       "newframe-b", "إطارات فاخرة ب"),
    (os.path.join(ROOT, "tools/solo"),                     "solo",       "توليد فردي فاخر"),
]

# ---------------------------------------------------------------- أدوات مساعدة
def slice_grid(img, tol=18, min_frac=0.008):
    """تقصّ الشبكة إلى خلايا عبر إسقاط الصفوف/الأعمدة لقناع الفرق عن الخلفية."""
    a = np.asarray(img).astype(int)
    h, w, _ = a.shape
    bg = np.median(a[:6].reshape(-1, 3), axis=0)          # لون الخلفية من أعلى الصورة
    mask = np.abs(a - bg).max(axis=2) > tol
    rows = mask.sum(axis=1) > w * min_frac
    bands, start = [], None
    for y in range(h):                                     # تجميع الصفوف المتتالية
        if rows[y] and start is None: start = y
        elif not rows[y] and start is not None:
            if y - start > 20: bands.append((start, y))
            start = None
    if start is not None: bands.append((start, h))

    # --- فصل الصفوف الملتصقة: النطاق الأطول من 1.45× الوسيط يُشق عند "الوادي" ---
    if bands:
        med = float(np.median([y1 - y0 for y0, y1 in bands]))
        fixed = []
        for (y0, y1) in bands:
            if y1 - y0 > 1.45 * med:
                rs = mask[y0:y1].sum(axis=1)
                strong = rs[rs > w * min_frac]
                thr = 0.2 * float(np.median(strong)) if len(strong) else 0
                off = int(0.12 * (y1 - y0))
                low = rs[off:int(0.88 * (y1 - y0))] < thr
                pts, s = [], None
                for i, v in enumerate(low):
                    if v and s is None: s = i
                    elif not v and s is not None:
                        if i - s >= 2: pts.append(y0 + off + (s + i) // 2)
                        s = None
                if s is not None and len(low) - s >= 2: pts.append(y0 + off + (s + len(low)) // 2)
                prev = y0
                for sp in pts:
                    if sp - prev > 40: fixed.append((prev, sp))
                    prev = sp
                if y1 - prev > 40: fixed.append((prev, y1))
            else:
                fixed.append((y0, y1))
        bands = fixed

    cells = []
    for (y0, y1) in bands:
        sub = mask[y0:y1]
        cols = sub.sum(axis=0) > (y1 - y0) * min_frac
        cstart = None
        for x in range(w):
            if cols[x] and cstart is None: cstart = x
            elif not cols[x] and cstart is not None:
                if x - cstart > 20: cells.append((y0, y1, cstart, x))
                cstart = None
        if cstart is not None: cells.append((y0, y1, cstart, w))
    return cells, bg

def fill_holes(m):
    """تعبئة الفراغات الداخلية (حتى لو كان مركز الزر أبيض كالخلفية)."""
    h, w = m.shape
    outside = np.zeros_like(m)
    dq = deque()
    for x in range(w):
        for y in (0, h - 1):
            if not m[y, x] and not outside[y, x]:
                outside[y, x] = True; dq.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if not m[y, x] and not outside[y, x]:
                outside[y, x] = True; dq.append((y, x))
    while dq:
        y, x = dq.popleft()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and not m[ny, nx] and not outside[ny, nx]:
                outside[ny, nx] = True; dq.append((ny, nx))
    return m | (~outside)

def _erode(m, it=1):
    for _ in range(it):
        p = np.pad(m, 1, constant_values=False)
        m = p[1:-1, 1:-1] & p[:-2, 1:-1] & p[2:, 1:-1] & p[1:-1, :-2] & p[1:-1, 2:]
    return m

def _dilate(m, it=1):
    for _ in range(it):
        p = np.pad(m, 1, constant_values=False)
        m = p[1:-1, 1:-1] | p[:-2, 1:-1] | p[2:, 1:-1] | p[1:-1, :-2] | p[1:-1, 2:]
    return m

def silhouette(cell_arr, bg, tol=12, opening=True, er=1):
    """قناع الزر: فتح مورفولوجي adaptif لإزالة الزوائد + تعبئة الداخل + حلق الهالة."""
    m = np.abs(cell_arr - bg).max(axis=2) > tol
    m = _dilate(m, 2)          # إغلاق فجوات الحواف الممزوجة قبل التعبئة
    m = fill_holes(m)
    m = _erode(m, 2)
    if opening:
        o = _dilate(_erode(m))
        # إذا كان الفتح سيدمّر أشكالاً منخفضة التباين (مفاتيح بيضاء) نتخطاه
        if o.sum() >= 0.55 * m.sum():
            m = fill_holes(o)
    m = _erode(m, er)          # حلق إضافي للخلفيات الرمادية يزيل الهالة
    return m

def color_name(r, g, b):
    h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    hue = h * 360
    if s < 0.12:
        if v > 0.85: return "white", "لؤلؤي أبيض"
        if v > 0.42: return "silver", "فضي رمادي"
        return "black", "أونيكس أسود"
    if s < 0.30 and v > 0.88 and hue < 70:
        return "white", "لؤلؤي أبيض"
    if hue < 14: return "ruby", "ياقوتي أحمر"
    if hue < 45:  return "gold", "ذهبي عنبري"
    if hue < 70:  return "yellow", "أصفر شمسي"
    if hue < 150: return "green", "أخضر زمردي"
    if hue < 195: return "mint", "نعناعي"
    if hue < 250: return "blue", "أزرق جليدي"
    if hue < 285: return "purple", "بنفسجي جمشتي"
    return "pink", "وردي"

def shade(rgb, f):
    return tuple(max(0, min(255, int(c * f))) for c in rgb)

def mix(rgb, other, t):
    return tuple(int(c + (o - c) * t) for c, o in zip(rgb, other))

def hx(rgb): return "#%02x%02x%02x" % rgb

# ---------------------------------------------------------------- 1) التقطيع
TCSS = os.path.join(PUB, "assets", "themes-css")
os.makedirs(TCSS, exist_ok=True)

buttons, backgrounds = [], []
for path, set_id, set_ar in SOURCES:
    # المصدر قد يكون شبكة صورة واحدة أو مجلد أزرار مولّدة فردياً
    items = []
    if os.path.isdir(path):
        for f in sorted(os.listdir(path)):
            if not f.lower().endswith(".png"): continue
            im = Image.open(os.path.join(path, f)).convert("RGB")
            cs, bg = slice_grid(im)
            items += [(im, c, bg) for c in cs]
    else:
        im = Image.open(path).convert("RGB")
        cs, bg = slice_grid(im)
        items = [(im, c, bg) for c in cs]
    print(f"[{set_id}] خلايا مكتشفة: {len(items)}")

    for i, (img, (y0, y1, x0, x1), bg) in enumerate(items, 1):
        arr = np.asarray(img.crop((x0, y0, x1, y1))).astype(int)
        bgv = bg.max() / 255.0
        graybg = bgv < 0.96                       # خلفية رمادية فاتحة مقابل ورقة بيضاء
        sil = silhouette(arr, bg, tol=6 if graybg else 16, er=2 if graybg else 1)
        ys, xs = np.where(sil)
        if len(ys) < 300: continue
        arr = arr[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
        sil = sil[ys.min():ys.max() + 1, xs.min():xs.max() + 1]

        # ---- ألفا ناعم: إزالة بقايا الخلفية والظلال خارج الإطار ----
        dist = np.abs(arr - bg).max(axis=2)
        m_strict = dist > (45 if graybg else 50)
        interior = None
        if m_strict.sum() > 50:
            cand = fill_holes(m_strict) & sil
            if cand.sum() >= 0.25 * sil.sum():
                interior = cand
        if interior is None:
            interior = _erode(sil, 3)
        mx = arr.max(axis=2) / 255.0
        mn = arr.min(axis=2) / 255.0
        sat = (mx - mn) / np.maximum(mx, 1e-6)
        shadow_cut = bgv * 0.985 if graybg else bgv * 0.90
        shadow = (sat < 0.20) & (mx > bgv * 0.55) & (mx < shadow_cut) & (~interior)
        d0, d1 = (14, 40) if graybg else (18, 48)
        soft = np.clip((dist - d0) / (d1 - d0), 0, 1)
        brighter = mx > bgv + 0.02
        alpha = np.where(interior | brighter, 1.0, soft)
        alpha = np.where(shadow, 0.0, alpha) * sil

        # ---- ترميم الثقوب: لمعات باهتة غير متصلة بالخارج تُستعاد معتمة ----
        low = (alpha < 0.3) & sil
        p = np.pad(~sil, 1, constant_values=False)
        out_adj = p[1:-1, 1:-1] | p[:-2, 1:-1] | p[2:, 1:-1] | p[1:-1, :-2] | p[1:-1, 2:]
        seed = low & out_adj
        keep = seed.copy()
        dq = deque(map(tuple, np.argwhere(seed)))
        while dq:
            y, x = dq.popleft()
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < low.shape[0] and 0 <= nx < low.shape[1] and low[ny, nx] and not keep[ny, nx]:
                    keep[ny, nx] = True
                    dq.append((ny, nx))
        alpha = np.where(low & ~keep, 1.0, alpha)

        # ---- فصل لون الحواف عن الخلفية (unmix) لإزالة الهالة الرمادية ----
        band = (alpha > 0.05) & (alpha < 0.95)
        a3 = np.clip(alpha, 0.3, 1.0)[..., None]
        arr = np.where(band[..., None], np.clip(bg + (arr - bg) / a3, 0, 255), arr)

        alpha8 = (np.clip(alpha, 0, 1) * 255).astype(np.uint8)
        aimg = Image.fromarray(alpha8, "L").filter(ImageFilter.GaussianBlur(0.6))

        # ---- شحذ الألوان ورفع الدقة ×1.75 ----
        rgb = Image.fromarray(arr.astype(np.uint8), "RGB")
        rgb = rgb.resize((rgb.width * 7 // 4, rgb.height * 7 // 4), Image.LANCZOS)
        rgb = rgb.filter(ImageFilter.UnsharpMask(radius=1.8, percent=150, threshold=2))
        aimg = aimg.resize(rgb.size, Image.LANCZOS)
        rgba = np.dstack([np.asarray(rgb), np.asarray(aimg)])
        bid = f"{set_id}-{i:02d}"
        Image.fromarray(rgba, "RGBA").save(os.path.join(BTN, f"btn-{bid}.png"), optimize=True)

        # لوحة اللون: متوسط "المركز الفارغ" للزر (هويته اللونية الحقيقية)
        ch, cw = arr.shape[0], arr.shape[1]
        base = tuple(int(c) for c in arr[int(ch * 0.32):int(ch * 0.68), int(cw * 0.32):int(cw * 0.68)].reshape(-1, 3).mean(axis=0))
        ck, cn = color_name(*base)
        pal = {"base": hx(base), "dark": hx(shade(base, 0.32)), "light": hx(mix(base, (255, 255, 255), 0.55))}

        # ملف ثيم مستقل لكل زر (CSS جاهز)
        cssp = f"assets/themes-css/theme-{bid}.css"
        _p = mix(base, (255, 255, 255), 0.45)
        _lum = 0.299 * _p[0] + 0.587 * _p[1] + 0.114 * _p[2]
        _txt = "#2b2130" if _lum > 150 else "#ffffff"
        with open(os.path.join(PUB, cssp), "w", encoding="utf-8") as fh:
            fh.write(f"""/* ثيماتي — ثيم «{cn} — {set_ar} {i}» (موحّد: خلفية + زر + لون خط) */
:root {{
  --theme-accent: {pal['base']};
  --theme-accent-dark: {pal['dark']};
  --theme-accent-light: {pal['light']};
  --theme-text: {_txt};
  --theme-wallpaper: url("../backgrounds/bg-{bid}.jpg");
  --theme-keycap: url("../buttons/btn-{bid}.png");
}}
.keyboard {{ background: var(--theme-wallpaper) center/cover; padding: 14px; border-radius: 22px; }}
.key {{
  background: var(--theme-keycap) center/100% 100% no-repeat;
  color: var(--theme-text);
  border: none; width: 52px; height: 70px; cursor: pointer;
  transition: transform .12s ease, filter .12s ease;
}}
.key:active {{ transform: translateY(3px) scale(.96); filter: brightness(1.15); }}
""")
        buttons.append({
            "id": bid, "set": set_id, "setAr": set_ar, "colorKey": ck, "colorAr": cn,
            "name": f"{cn} — {set_ar} {i}",
            "src": f"assets/buttons/btn-{bid}.png",
            "css": cssp,
            "palette": pal,
        })

# ---------------------------------------------------------------- 2) الخلفيات المطابقة
def make_background(btn, seed):
    p = btn["palette"]
    base = tuple(int(p["base"][i:i + 2], 16) for i in (1, 3, 5))
    dark = tuple(int(p["dark"][i:i + 2], 16) for i in (1, 3, 5))
    light = tuple(int(p["light"][i:i + 2], 16) for i in (1, 3, 5))
    W, H = 720, 1280
    rnd = random.Random(seed)
    # تدرج عمودي + توهج علوي
    ys = np.linspace(0, 1, H)[:, None, None]
    grad = (np.array(dark) * (1 - ys) + np.array(mix(base, (0, 0, 0), 0.25)) * ys)
    yy, xx = np.mgrid[0:H, 0:W]
    g = np.exp(-(((xx - W * 0.5) ** 2) / (2 * (W * 0.42) ** 2) + ((yy - H * 0.26) ** 2) / (2 * (H * 0.20) ** 2)))
    grad = grad + g[..., None] * (np.array(light) - grad) * 0.55
    im = Image.fromarray(np.clip(grad, 0, 255).astype(np.uint8), "RGB")
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    # دوائر بوكيه ناعمة بلون الزر الفاتح
    for _ in range(16):
        r = rnd.randint(30, 130)
        x, y = rnd.randint(-40, W), rnd.randint(-40, H)
        d.ellipse([x - r, y - r, x + r, y + r], fill=light + (rnd.randint(14, 34),))
    # موجات سفلية بلون أغمق
    for k in range(3):
        pts = [(0, H)]
        base_y = H - 190 + k * 62
        for x in range(0, W + 1, 24):
            pts.append((x, base_y + 34 * np.sin(x / 90 + k * 1.7)))
        pts += [(W, H)]
        d.polygon(pts, fill=shade(base, 0.45) + (46 + k * 22,))
    # إطار زخرفي يطابق طراز الزر (مستطيل دائري مزدوج + زوايا)
    m1, m2 = 64, 88
    d.rounded_rectangle([m1, m1, W - m1, H - m1], radius=46, outline=light + (120,), width=4)
    d.rounded_rectangle([m2, m2, W - m2, H - m2], radius=34, outline=light + (70,), width=2)
    for cx, cy in [(m1, m1), (W - m1, m1), (m1, H - m1), (W - m1, H - m1)]:
        d.ellipse([cx - 9, cy - 9, cx + 9, cy + 9], fill=light + (160,))
    d.ellipse([W / 2 - 14, m1 - 14, W / 2 + 14, m1 + 14], fill=light + (200,))
    d.ellipse([W / 2 - 14, H - m1 - 14, W / 2 + 14, H - m1 + 14], fill=light + (200,))
    ov = ov.filter(ImageFilter.GaussianBlur(1))
    im = Image.alpha_composite(im.convert("RGBA"), ov)
    # فينييت خفيف
    vig = Image.new("L", (W, H), 0)
    dv = ImageDraw.Draw(vig)
    dv.ellipse([-W * 0.35, -H * 0.25, W * 1.35, H * 1.25], fill=255)
    vig = vig.filter(ImageFilter.GaussianBlur(120))
    black = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    im = Image.composite(im, Image.alpha_composite(im, black), vig)
    out = os.path.join(BGD, f"bg-{btn['id']}.jpg")
    im.convert("RGB").save(out, "JPEG", quality=82)
    return out

for idx, btn in enumerate(buttons):
    make_background(btn, seed=idx + 7)
    backgrounds.append({
        "id": btn["id"], "name": f"خلفية {btn['name']}",
        "src": f"assets/backgrounds/bg-{btn['id']}.jpg",
        "forButton": btn["id"], "palette": btn["palette"],
    })
print("خلفيات:", len(backgrounds))

# ---------------------------------------------------------------- 3) حِزم الثيمات
THEMES = [
    ("ruby",   "رويال روبي",    "ياقوتي ملكي بأزرار مذهّبة وخلفية حمراء عميقة"),
    ("pink",   "وردي حالِم",    "نعومة وردية بلؤلؤ وفيونكات وخلفية غروب وردي"),
    ("mint",   "مينت منعش",     "خضرة نعناعية هادئة بأوراق وزهور وخلفية غابة"),
    ("gold",   "ذهب ملوكي",     "فخامة ذهبية بتيجان وأشعة وخلفية عنبر دافئة"),
    ("blue",   "أزرق جليدي",    "برودة بلورية بثلج وألماس وخلفية صقيع"),
    ("purple", "جمشت الليل",    "بنفسج ساحر بأطر بلورية وخلفية ليل بنفسجية"),
    ("black",  "أونيكس وفضة",   "غموض داكن بفضة وأونيكس وخلفية ليلية فاخرة"),
    ("white",  "لؤلؤة بيضاء",   "صفاء لؤلؤي بزهور بيضاء وخلفية عاجية"),
]
GROUP_OF = {"ruby": ["ruby"], "pink": ["pink"], "mint": ["mint", "green"],
            "gold": ["gold", "yellow"], "blue": ["blue"], "purple": ["purple"],
            "black": ["black", "silver"], "white": ["white"]}
themes = []
for tid, tname, tdesc in THEMES:
    pool = [b for b in buttons if b["colorKey"] in GROUP_OF[tid]]
    pick = []
    for s in ["glossy", "jewel", "frame", "newframe-a", "newframe-b"]:   # تنويع المجموعات
        pick += [b for b in pool if b["set"] == s][:2]
    pick = pick[:8] or pool[:8]
    if not pick: continue
    bg = next(b for b in backgrounds if b["id"] == pick[0]["id"])
    accent = pick[0]["palette"]["base"]
    css = f"""/* ثيماتي — ثيم «{tname}» */
:root {{
  --theme-accent: {accent};
  --theme-accent-dark: {pick[0]['palette']['dark']};
  --theme-accent-light: {pick[0]['palette']['light']};
  --theme-wallpaper: url("wallpaper.jpg");
}}
.keyboard {{ background: var(--theme-wallpaper) center/cover; padding: 18px; border-radius: 24px; }}
.key {{
  background: url("buttons/{os.path.basename(pick[0]['src'])}") center/contain no-repeat;
  border: none; width: 56px; height: 74px; cursor: pointer;
  transition: transform .12s ease, filter .12s ease;
}}
.key:active {{ transform: translateY(3px) scale(.96); filter: brightness(1.15); }}
"""
    zpath = os.path.join(DLTH, f"theme-{tid}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("theme.css", css)
        z.writestr("README.txt", f"ثيماتي — ثيم «{tname}»\n{tdesc}\n\nالمحتويات:\n- wallpaper.jpg خلفية الثيم\n- buttons/ أزرار الثيم (PNG شفاف)\n- theme.css أنماط جاهزة\n")
        z.write(os.path.join(BGD, f"bg-{bg['id']}.jpg"), "wallpaper.jpg")
        for b in pick:
            z.write(os.path.join(BTN, f"btn-{b['id']}.png"), f"buttons/btn-{b['id']}.png")
    themes.append({
        "id": tid, "name": tname, "desc": tdesc, "accent": accent,
        "bg": bg["src"], "buttons": [b["src"] for b in pick],
        "zip": f"downloads/themes/theme-{tid}.zip",
        "count": len(pick) + 2,
    })
print("ثيمات:", len(themes))

# ---------------------------------------------------------------- 4) حِزم التفاعلات
EFFECTS = [
    ("ripple", "تموّج مائي", "دائرة ضوء تتمدد من نقطة اللمس نحو أطراف المفتاح"),
    ("glow", "توهّج نابض", "هالة ضوء نابضة تحيط بالمفتاح لحظة الضغط"),
    ("sink", "انغمار ثلاثي الأبعاد", "ينغمس المفتاح للأسفل بظلّه كما في الكيبورد الحقيقي"),
    ("sparkle", "شرارات لامعة", "شرارات متناثرة تنفجر حول المفتاح عند الضغط"),
    ("bounce", "ارتداد مطاطي", "قفزة مرنة مرحة يعود بها المفتاح لمكانه"),
    ("neon", "وميض نيون", "ومضة نيون متبدلة الألوان تجتاح حواف المفتاح"),
    ("bubbles", "فقاعات صاعدة", "فقاعات صغيرة تصعد من المفتاح وتختفي"),
    ("wave", "موجة لونية", "موجة تدرج لوني تجتاح سطح المفتاح أفقياً"),
]
FX_CSS = {
 "ripple": """.key{position:relative;overflow:hidden}
.key .fx-ripple{position:absolute;border-radius:50%;background:rgba(255,255,255,.55);transform:scale(0);animation:fxRip .6s ease-out forwards;pointer-events:none}
@keyframes fxRip{to{transform:scale(3.4);opacity:0}}""",
 "glow": """.key.fx-glow{animation:fxGlow .55s ease}
@keyframes fxGlow{0%{box-shadow:0 0 0 0 rgba(255,255,255,.75)}70%{box-shadow:0 0 26px 12px rgba(255,255,255,.25)}100%{box-shadow:0 0 0 0 rgba(255,255,255,0)}}""",
 "sink": """.key{transition:transform .1s ease,box-shadow .1s ease}
.key.fx-sink{transform:translateY(5px) scale(.96);box-shadow:0 1px 2px rgba(0,0,0,.4)!important}""",
 "sparkle": """.key{position:relative}
.fx-spark{position:absolute;width:7px;height:7px;border-radius:50%;background:#fff;box-shadow:0 0 8px 2px rgba(255,255,255,.8);pointer-events:none;animation:fxSpark .7s ease-out forwards}
@keyframes fxSpark{to{transform:translate(var(--dx),var(--dy)) scale(0);opacity:0}}""",
 "bounce": """.key.fx-bounce{animation:fxBounce .5s cubic-bezier(.28,.84,.42,1)}
@keyframes fxBounce{0%{transform:scale(1)}30%{transform:scale(.88,.8) translateY(4px)}60%{transform:scale(1.08,.94) translateY(-8px)}100%{transform:scale(1)}}""",
 "neon": """.key.fx-neon{animation:fxNeon .6s linear}
@keyframes fxNeon{0%{box-shadow:0 0 12px 3px #f472b6}33%{box-shadow:0 0 12px 3px #34d399}66%{box-shadow:0 0 12px 3px #60a5fa}100%{box-shadow:0 0 0 0 transparent}}""",
 "bubbles": """.key{position:relative}
.fx-bub{position:absolute;bottom:6px;border-radius:50%;border:1.5px solid rgba(255,255,255,.85);background:rgba(255,255,255,.18);pointer-events:none;animation:fxBub .9s ease-in forwards}
@keyframes fxBub{to{transform:translateY(-70px) scale(1.25);opacity:0}}""",
 "wave": """.key{position:relative;overflow:hidden}
.key.fx-wave::after{content:"";position:absolute;inset:0;background:linear-gradient(100deg,transparent 20%,rgba(255,255,255,.55) 50%,transparent 80%);transform:translateX(-120%);animation:fxWave .55s ease forwards}
@keyframes fxWave{to{transform:translateX(120%)}}""",
}
FX_JS = {
 "ripple": """document.querySelectorAll('.key').forEach(k=>k.addEventListener('pointerdown',e=>{
  const b=k.getBoundingClientRect(),s=Math.max(b.width,b.height),r=document.createElement('span');
  r.className='fx-ripple';r.style.width=r.style.height=s+'px';
  r.style.left=(e.clientX-b.left-s/2)+'px';r.style.top=(e.clientY-b.top-s/2)+'px';
  k.appendChild(r);setTimeout(()=>r.remove(),650);}));""",
 "glow": """document.querySelectorAll('.key').forEach(k=>k.addEventListener('pointerdown',()=>{
  k.classList.remove('fx-glow');void k.offsetWidth;k.classList.add('fx-glow');}));""",
 "sink": """document.querySelectorAll('.key').forEach(k=>{
  k.addEventListener('pointerdown',()=>k.classList.add('fx-sink'));
  k.addEventListener('pointerup',()=>k.classList.remove('fx-sink'));
  k.addEventListener('pointerleave',()=>k.classList.remove('fx-sink'));});""",
 "sparkle": """document.querySelectorAll('.key').forEach(k=>k.addEventListener('pointerdown',()=>{
  for(let i=0;i<8;i++){const s=document.createElement('span');s.className='fx-spark';
   const a=Math.random()*Math.PI*2,d=30+Math.random()*30;
   s.style.left='50%';s.style.top='50%';
   s.style.setProperty('--dx',Math.cos(a)*d+'px');s.style.setProperty('--dy',Math.sin(a)*d+'px');
   k.appendChild(s);setTimeout(()=>s.remove(),750);}}));""",
 "bounce": """document.querySelectorAll('.key').forEach(k=>k.addEventListener('pointerdown',()=>{
  k.classList.remove('fx-bounce');void k.offsetWidth;k.classList.add('fx-bounce');}));""",
 "neon": """document.querySelectorAll('.key').forEach(k=>k.addEventListener('pointerdown',()=>{
  k.classList.remove('fx-neon');void k.offsetWidth;k.classList.add('fx-neon');}));""",
 "bubbles": """document.querySelectorAll('.key').forEach(k=>k.addEventListener('pointerdown',()=>{
  for(let i=0;i<5;i++){const b=document.createElement('span');b.className='fx-bub';
   const s=6+Math.random()*10;b.style.width=b.style.height=s+'px';
   b.style.left=(15+Math.random()*70)+'%';b.style.animationDelay=(Math.random()*.25)+'s';
   k.appendChild(b);setTimeout(()=>b.remove(),1200);}}));""",
 "wave": """document.querySelectorAll('.key').forEach(k=>k.addEventListener('pointerdown',()=>{
  k.classList.remove('fx-wave');void k.offsetWidth;k.classList.add('fx-wave');
  setTimeout(()=>k.classList.remove('fx-wave'),600);}));""",
}
effects = []
for eid, ename, edesc in EFFECTS:
    zpath = os.path.join(DLFX, f"effect-{eid}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("effect.css", FX_CSS[eid])
        z.writestr("effect.js", FX_JS[eid])
        z.writestr("README.txt", f"ثيماتي — تفاعل «{ename}»\n{edesc}\n\nطريقة الاستخدام:\n1) أضف class=\"key\" لأزرار المفاتيح.\n2) اربط effect.css و effect.js بصفحتك.\n")
    effects.append({"id": eid, "name": ename, "desc": edesc, "zip": f"downloads/effects/effect-{eid}.zip"})
print("تفاعلات:", len(effects))

# ---------------------------------------------------------------- 5) data.js
data = {"buttons": buttons, "backgrounds": backgrounds, "themes": themes, "effects": effects,
        "sets": [{"id": s, "ar": a} for _, s, a in SOURCES]}
with open(os.path.join(PUB, "assets", "data.js"), "w", encoding="utf-8") as f:
    f.write("window.LIB = " + json.dumps(data, ensure_ascii=False) + ";\n")
print("أزرار:", len(buttons), "| المجموعات:", {s: sum(1 for b in buttons if b['set'] == s) for _, s, _ in SOURCES})
