# -*- coding: utf-8 -*-
"""
إعادة توليد الأزرار اللامعة بأسلوب مسطح ناعم (مثل المرجع):
جسم بتدرج لطيف + خط حدود رفيع داكن + حافة فاتحة خارجية، بلا لوحة أو زخرفة
+ إعادة توليد خلفياتها بنفس لون كل زر (تدرج + توهج مركزي + فينييت)
"""
import os, json
from PIL import Image, ImageDraw, ImageFilter

PUB = "/home/user/theme-store/public"
BTN = os.path.join(PUB, "assets", "buttons")
BGD = os.path.join(PUB, "assets", "backgrounds")
W, H = 448, 616
BW, BH = 720, 1280
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

def px(h): return tuple(int(h[i:i+2], 16) for i in (1, 3, 5))
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def vgrad(w, h, stops):
    img = Image.new("RGB", (w, h))
    p = img.load()
    for y in range(h):
        t = y / max(h - 1, 1)
        c = stops[-1][1]
        for i in range(len(stops) - 1):
            p0, c0 = stops[i]; p1, c1 = stops[i + 1]
            if t <= p1:
                lt = 0 if p1 == p0 else min(max((t - p0) / (p1 - p0), 0), 1)
                c = mix(c0, c1, lt)
                break
        for x in range(w): p[x, y] = c
    return img

def rmask(w, h, r):
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=255)
    return m

def flat_button(pal):
    base = px(pal["base"])
    r = 96
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([14, 20, W - 14, H - 10], radius=r, fill=(0, 0, 0, 90))
    img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(10)))
    body = vgrad(W, H, [(0, mix(base, WHITE, 0.30)), (0.5, mix(base, WHITE, 0.10)), (1, mix(base, BLACK, 0.08))])
    img.paste(body, (0, 0), rmask(W, H, r))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([7, 9, W - 8, H - 8], radius=r - 4, outline=mix(base, WHITE, 0.50), width=2)
    d.rounded_rectangle([15, 17, W - 16, H - 16], radius=r - 10, outline=mix(base, BLACK, 0.38), width=3)
    sheen = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sheen).ellipse([60, -H * 0.22, W - 60, H * 0.30], fill=(255, 255, 255, 26))
    img = Image.alpha_composite(img, sheen.filter(ImageFilter.GaussianBlur(18)))
    return img

def tinted_wallpaper(pal):
    base = px(pal["base"])
    bg = vgrad(BW, BH, [(0, mix(base, WHITE, 0.38)), (0.5, mix(base, WHITE, 0.16)), (1, mix(base, BLACK, 0.18))])
    bg = bg.convert("RGBA")
    glow = Image.new("RGBA", (BW, BH), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([BW * 0.12, BH * 0.22, BW * 0.88, BH * 0.66], fill=(255, 255, 255, 34))
    bg = Image.alpha_composite(bg, glow.filter(ImageFilter.GaussianBlur(90)))
    vig = Image.new("L", (BW, BH), 0)
    ImageDraw.Draw(vig).ellipse([-BW * 0.25, -BH * 0.15, BW * 1.25, BH * 1.15], fill=255)
    vig = vig.filter(ImageFilter.GaussianBlur(160))
    dark = Image.new("RGBA", (BW, BH), (12, 9, 16, 0))
    dark.putalpha(vig.point(lambda v: int((255 - v) * 0.42)))
    bg = Image.alpha_composite(bg, dark)
    return bg.convert("RGB")

s = open(os.path.join(PUB, "assets", "data.js"), encoding="utf-8").read()
D = json.loads(s[len("window.LIB = "):-2])
n = 0
for b in D["buttons"]:
    if b["set"] != "glossy":
        continue
    flat_button(b["palette"]).save(os.path.join(BTN, f"btn-{b['id']}.png"), optimize=True)
    tinted_wallpaper(b["palette"]).save(os.path.join(BGD, f"bg-{b['id']}.jpg"), quality=88, optimize=True)
    n += 1
print(f"تمت إعادة توليد {n} زراً لامعاً مسطحاً + {n} خلفية بنفس اللون")
