# -*- coding: utf-8 -*-
"""
مولّد التصاميم الإسلامية — ثيماتي
12 زراً بشكل قوس محراب (ميhrab) بزخرفة هندسية (أضلاع ثمانية) وإطار مزدوج
وزخرفة علوية متبدلة (هلال/نجمة ثمانية/فانوس/قبة) + 12 خلفية مشهدية:
سماء ليلية بنمط هندسي، هلال متوهج، نجوم، سيلويت مسجد بمآذن، فوانيس، شريط زخرفي
"""
import os, json, math, random
from PIL import Image, ImageDraw, ImageFilter

PUB = "/home/user/theme-store/public"
BTN = os.path.join(PUB, "assets", "buttons")
BGD = os.path.join(PUB, "assets", "backgrounds")
CSS = os.path.join(PUB, "assets", "themes-css")
W, H = 448, 616
BW, BH = 720, 1280
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GOLD = (212, 168, 60)
GOLD_L = (250, 220, 140)

def px(h): return tuple(int(h[i:i+2], 16) for i in (1, 3, 5))
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def hx(c): return "#%02x%02x%02x" % tuple(c)

def vgrad(w, h, stops):
    img = Image.new("RGB", (w, h))
    p = img.load()
    for y in range(h):
        t = y / max(h - 1, 1)
        c = stops[-1][1]
        for i in range(len(stops) - 1):
            p0, c0 = stops[i]; p1, c1 = stops[i + 1]
            if t <= p1:
                lt = 0 if p1 == p0 else min(max((t - p0) / (p1 - p0), 0), 1)
                c = mix(c0, c1, lt)
                break
        for x in range(w): p[x, y] = c
    return img

def _arch_poly(w, h, inset=0):
    """نقاط قوس مدبب بترتيب بسيط بلا تقاطع: قمة ← منحنى أيسر ← قاعدة ← منحنى أيمن."""
    ax, ay = w / 2, 10 + inset
    sy = int(h * 0.42)
    pts = [(ax, ay)]
    curves = {}
    for side in (-1, 1):
        cx, cy = w / 2 + side * w * 0.40, h * 0.06 + inset   # نقطة التحكم
        ex, ey = (inset + 4) if side < 0 else (w - inset - 4), sy
        curve = []
        for k in range(1, 15):
            t = k / 14
            x = (1 - t) ** 2 * ax + 2 * (1 - t) * t * cx + t ** 2 * ex
            y = (1 - t) ** 2 * ay + 2 * (1 - t) * t * cy + t ** 2 * ey
            curve.append((x, y))
        curves[side] = curve
    pts += curves[-1]                                   # القمة ← الكتف الأيسر
    pts += [(inset + 4, int(h * 0.50)), (w - inset - 4, int(h * 0.50))]   # القاعدة
    pts += list(reversed(curves[1]))                    # الكتف الأيمن ← القمة
    return pts

def arch_mask(w, h, inset=0, r=48):
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    d.rounded_rectangle([inset, int(h * 0.34), w - 1 - inset, h - 1 - inset], radius=r, fill=255)
    d.polygon(_arch_poly(w, h, inset), fill=255)
    return m

def ring(mask_out, mask_in, color, alpha=255):
    """حلقة بين قناعين = حدود بشكل القوس."""
    edge = Image.new("L", mask_out.size, 0)
    edge.paste(mask_out, (0, 0))
    edge = Image.composite(Image.new("L", mask_out.size, 0), edge, mask_in)
    lay = Image.new("RGBA", mask_out.size, color + (alpha,))
    lay.putalpha(edge)
    return lay

def star8(d, cx, cy, r, color, inner=0.46):
    pts = []
    for k in range(16):
        a = math.radians(k * 22.5 - 90)
        rr = r if k % 2 == 0 else r * inner
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    d.polygon(pts, fill=color)

def crescent(d, cx, cy, r, color):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color)
    d.ellipse([cx - r * 0.72, cy - r * 0.86, cx + r * 0.92, cy + r * 0.62], fill=(0, 0, 0, 0))
    return

def crescent_img(r, color):
    s = r * 3
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse([r * 0.5, r * 0.5, r * 2.5, r * 2.5], fill=color)
    cut = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ImageDraw.Draw(cut).ellipse([r * 0.95, r * 0.35, r * 2.95, r * 2.35], fill=(255, 255, 255, 255))
    im.putalpha(Image.composite(Image.new("L", (s, s), 0), im.split()[3], cut.split()[3]))
    return im

def lantern(d, cx, cy, s, color):
    d.polygon([(cx - s * 0.4, cy - s * 0.3), (cx + s * 0.4, cy - s * 0.3), (cx + s * 0.55, cy + s * 0.25),
               (cx, cy + s * 0.75), (cx - s * 0.55, cy + s * 0.25)], fill=color)
    d.ellipse([cx - s * 0.22, cy - s * 0.62, cx + s * 0.22, cy - s * 0.22], fill=color)
    d.line([cx, cy - s * 0.62, cx, cy - s * 0.95], fill=color, width=3)
    d.ellipse([cx - 4, cy + s * 0.75, cx + 4, cy + s * 0.95], fill=color)

def girih_overlay(w, h, color, alpha, step=64):
    ov = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    for yy in range(step // 2, h, step):
        for xx in range(step // 2, w, step):
            star8(d, xx, yy, step * 0.30, color + (alpha,))
    return ov

ORN = ["crescent", "star8", "lantern", "dome"]

def build_islamic(pal, idx):
    base = px(pal["base"])
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([16, 26, W - 16, H - 12], radius=52, fill=(0, 0, 0, 105))
    img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(11)))
    body = vgrad(W, H, [(0, mix(base, WHITE, 0.30)), (0.5, base), (1, mix(base, BLACK, 0.32))])
    m0 = arch_mask(W, H)
    img.paste(body, (0, 0), m0)
    # زخرفة هندسية داخل الجسم
    ov = girih_overlay(W, H, mix(base, WHITE, 0.55), 26, 64)
    ov.putalpha(Image.composite(ov.split()[3], Image.new("L", (W, H), 0), m0))
    img = Image.alpha_composite(img, ov)
    # لمعة علوية
    gloss = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(gloss).ellipse([60, -H * 0.20, W - 60, H * 0.30], fill=(255, 255, 255, 52))
    gl = gloss.filter(ImageFilter.GaussianBlur(14))
    gl.putalpha(Image.composite(gl.split()[3], Image.new("L", (W, H), 0), m0))
    img = Image.alpha_composite(img, gl)
    # إطار مزدوج بشكل القوس
    img = Image.alpha_composite(img, ring(m0, arch_mask(W, H, 7), mix(base, WHITE, 0.55)))
    img = Image.alpha_composite(img, ring(arch_mask(W, H, 12), arch_mask(W, H, 16), GOLD))
    d = ImageDraw.Draw(img)
    # لوحة المركز (قوس أصغر) فارغة
    ci = 56
    pw, ph = W - ci * 2, H - ci * 2 - 6
    pm = arch_mask(pw, ph, 0, 34)
    panel = vgrad(pw, ph, [(0, mix(base, WHITE, 0.52)), (1, mix(base, WHITE, 0.34))])
    img.paste(panel, (ci, ci + 4), pm)
    ro = Image.new("L", (W, H), 0); ro.paste(arch_mask(pw, ph, 0, 34), (ci, ci + 4))
    ri = Image.new("L", (W, H), 0); ri.paste(arch_mask(pw, ph, 3, 32), (ci + 3, ci + 7))
    img = Image.alpha_composite(img, ring(ro, ri, mix(base, BLACK, 0.28)))
    d = ImageDraw.Draw(img)
    # زخرفة الإطار العلوية
    orn = ORN[idx % 4]
    cx, cy = W // 2, int(H * 0.075)
    if orn == "crescent":
        cim = crescent_img(26, GOLD_L)
        img.paste(cim, (cx - cim.width // 2 + 8, cy - 18), cim)
        star8(d, cx - 26, cy + 6, 10, GOLD_L)
    elif orn == "star8":
        star8(d, cx, cy + 6, 26, GOLD_L)
        star8(d, cx, cy + 6, 12, mix(base, WHITE, 0.7))
    elif orn == "lantern":
        lantern(d, cx, cy + 10, 30, GOLD_L)
    else:
        d.polygon([(cx - 26, cy + 16), (cx + 26, cy + 16), (cx + 18, cy - 2), (cx, cy - 16), (cx - 18, cy - 2)], fill=GOLD_L)
        d.line([cx, cy - 16, cx, cy - 26], fill=GOLD_L, width=3)
        d.ellipse([cx - 3, cy - 30, cx + 3, cy - 24], fill=GOLD_L)
    for sx in (26, W - 26):
        star8(d, sx, int(H * 0.36), 12, GOLD_L)
    for yy in range(int(H * 0.44), H - 40, 52):
        d.ellipse([16, yy - 4, 24, yy + 4], fill=GOLD)
        d.ellipse([W - 24, yy - 4, W - 16, yy + 4], fill=GOLD)
    return img

# ---------------- الخلفيات الإسلامية ----------------
def bg_islamic(pal, idx):
    base = px(pal["base"])
    rnd = random.Random(idx * 77 + 5)
    img = vgrad(BW, BH, [(0, mix(base, BLACK, 0.62)), (0.55, mix(base, BLACK, 0.34)), (1, mix(base, BLACK, 0.70))])
    img = img.convert("RGBA")
    ov = girih_overlay(BW, BH, mix(base, WHITE, 0.5), 16, 96)
    img = Image.alpha_composite(img, ov)
    d = ImageDraw.Draw(img)
    # نجوم
    for k in range(60):
        x, y = rnd.randint(0, BW), rnd.randint(0, int(BH * 0.55))
        s = rnd.randint(1, 3)
        d.ellipse([x, y, x + s, y + s], fill=(255, 255, 240, rnd.randint(120, 230)))
    # هلال متوهج
    glow = Image.new("RGBA", (BW, BH), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([BW * 0.60, BH * 0.06, BW * 0.92, BH * 0.22], fill=(255, 240, 190, 90))
    img = Image.alpha_composite(img, glow.filter(ImageFilter.GaussianBlur(40)))
    cim = crescent_img(74, (250, 236, 190))
    img.paste(cim, (int(BW * 0.68), int(BH * 0.08)), cim)
    d = ImageDraw.Draw(img)
    # فوانيس معلقة
    for fx in (BW * 0.16, BW * 0.86):
        d.line([fx, 0, fx, BH * 0.16], fill=GOLD, width=3)
        lg = Image.new("RGBA", (BW, BH), (0, 0, 0, 0))
        ImageDraw.Draw(lg).ellipse([fx - 60, BH * 0.16 - 20, fx + 60, BH * 0.16 + 110], fill=(255, 200, 90, 80))
        img = Image.alpha_composite(img, lg.filter(ImageFilter.GaussianBlur(24)))
        d = ImageDraw.Draw(img)
        lantern(d, fx, BH * 0.16 + 40, 44, GOLD_L)
    # سيلويت المسجد
    mc = mix(base, BLACK, 0.78)
    gy = int(BH * 0.72)
    d.rectangle([0, gy + 90, BW, BH], fill=mc)
    d.ellipse([BW * 0.30, gy - 130, BW * 0.70, gy + 110], fill=mc)          # القبة الكبرى
    d.polygon([(BW * 0.46, gy - 190), (BW * 0.50, gy - 230), (BW * 0.54, gy - 190)], fill=mc)
    d.line([BW * 0.50, gy - 230, BW * 0.50, gy - 260], fill=mc, width=6)
    cim2 = crescent_img(16, mc)
    img.paste(cim2, (int(BW * 0.50) - 24, gy - 300), cim2)
    d = ImageDraw.Draw(img)
    for dx in (BW * 0.16, BW * 0.84):                                       # مئذنتان
        d.rectangle([dx - 22, gy - 160, dx + 22, gy + 120], fill=mc)
        d.rectangle([dx - 32, gy - 60, dx + 32, gy - 40], fill=mc)
        d.polygon([(dx - 22, gy - 160), (dx, gy - 230), (dx + 22, gy - 160)], fill=mc)
    for dx in (BW * 0.30, BW * 0.70):                                       # قبتان جانبيتان
        d.ellipse([dx - 60, gy - 10, dx + 60, gy + 90], fill=mc)
    # نوافذ متوهجة
    for k in range(7):
        wx = BW * 0.24 + k * BW * 0.085
        d.rounded_rectangle([wx - 10, gy + 20, wx + 10, gy + 66], radius=10, fill=(255, 214, 130, 200))
    # شريط زخرفي سفلي
    d.rectangle([0, BH - 64, BW, BH], fill=mix(base, BLACK, 0.55))
    for xx in range(0, BW, 48):
        d.polygon([(xx + 24, BH - 56), (xx + 44, BH - 32), (xx + 24, BH - 8), (xx + 4, BH - 32)], outline=GOLD_L, width=3)
    # فينييت
    vig = Image.new("L", (BW, BH), 0)
    ImageDraw.Draw(vig).ellipse([-BW * 0.25, -BH * 0.15, BW * 1.25, BH * 1.15], fill=255)
    vig = vig.filter(ImageFilter.GaussianBlur(160))
    dark = Image.new("RGBA", (BW, BH), (10, 8, 14, 0))
    dark.putalpha(vig.point(lambda v: int((255 - v) * 0.40)))
    img = Image.alpha_composite(img, dark)
    return img.convert("RGB")

PAL = [
    ("royal", "#7a3bb8", "#2a1245", "#d9b8f2", "بنفسجي ملكي"),
    ("magenta", "#c04a9a", "#45163a", "#eec2e0", "بنفسجي وردي"),
    ("gold", "#d4a437", "#4a3510", "#f2dcae", "ذهبي مسجدي"),
    ("green", "#2e8b57", "#0e3320", "#a8d8c0", "أخضر إسلامي"),
    ("turq", "#2aa8a0", "#0e3a37", "#aee0dc", "تركوازي"),
    ("black", "#3a3342", "#12101a", "#b8b0c8", "أسود ذهبي"),
    ("silver", "#d8d4e0", "#474354", "#f2f0f7", "أبيض فضي"),
    ("blue", "#3a6bc0", "#12244a", "#b8ccf0", "أزرق قبة"),
    ("ruby", "#b8304a", "#420e1a", "#e8b0bc", "ياقوتي"),
    ("emerald", "#1f9a6a", "#0a3524", "#a0dcc4", "زمردي"),
    ("night", "#4a4a7a", "#16162e", "#c0c0e0", "ليلي بنفسجي"),
    ("sand", "#c8a878", "#453622", "#ecdcc0", "رملي"),
]

s = open(os.path.join(PUB, "assets", "data.js"), encoding="utf-8").read()
D = json.loads(s[len("window.LIB = "):-2])
if "islamic" not in {x["id"] for x in D["sets"]}:
    D["sets"].append({"id": "islamic", "ar": "تصاميم إسلامية"})
have = {b["id"] for b in D["buttons"]}
n = 0
for i, (ck, base, dark, light, car) in enumerate(PAL, 1):
    bid = f"islamic-{i:02d}"
    if bid in have:
        continue
    pal = {"base": base, "dark": dark, "light": light}
    build_islamic(pal, i).save(os.path.join(BTN, f"btn-{bid}.png"), optimize=True)
    bg_islamic(pal, i).save(os.path.join(BGD, f"bg-{bid}.jpg"), quality=88, optimize=True)
    p = mix(px(base), (255, 255, 255), 0.45)
    lum = 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]
    txt = dark if lum > 150 else hx(mix(px(light), (255, 255, 255), 0.45))
    open(os.path.join(CSS, f"theme-{bid}.css"), "w", encoding="utf-8").write(
        f"""/* ثيماتي — ثيم «{car} — تصاميم إسلامية {i}» */
:root {{
  --theme-accent: {base};
  --theme-accent-dark: {dark};
  --theme-accent-light: {light};
  --theme-text: {txt};
  --theme-wallpaper: url("../backgrounds/bg-{bid}.jpg");
  --theme-keycap: url("../buttons/btn-{bid}.png");
}}
.keyboard {{ background: var(--theme-wallpaper) center/cover; padding: 14px; border-radius: 22px; }}
.key {{
  background: var(--theme-keycap) center/100% 100% no-repeat;
  color: var(--theme-text);
  border: none; width: 52px; height: 70px; cursor: pointer;
  transition: transform .12s ease, filter .12s ease;
}}
.key:active {{ transform: translateY(3px) scale(.96); filter: brightness(1.15); }}
""")
    D["buttons"].append({"id": bid, "set": "islamic", "setAr": "تصاميم إسلامية", "colorKey": ck, "colorAr": car,
                         "name": f"{car} — إسلامي {i}", "src": f"assets/buttons/btn-{bid}.png",
                         "css": f"assets/themes-css/theme-{bid}.css", "palette": pal})
    D["backgrounds"].append({"id": bid, "name": f"خلفية {car} — مسجد وهلال {i}", "src": f"assets/backgrounds/bg-{bid}.jpg",
                             "forButton": bid, "palette": pal})
    n += 1
open(os.path.join(PUB, "assets", "data.js"), "w", encoding="utf-8").write("window.LIB = " + json.dumps(D, ensure_ascii=False) + ";\n")
print(f"تمت إضافة {n} زراً إسلامياً وخلفية — الإجمالي {len(D['buttons'])} زر / {len(D['backgrounds'])} خلفية")
