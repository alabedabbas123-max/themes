# -*- coding: utf-8 -*-
"""
مولّد أيقونات التفاعلات — 24 أيقونة PNG شفافة 512×512 بهالة توهج:
شفاه، فقاعة، نار، ثلج، وردة، قلب، بريق، فراشة، أوراق، نجمة، قطرة، ساكورا،
هلال، شمس، جوهرة، نفلة، ريشة، برق، سحابة، كرز، قلبان، لؤلؤة، تاج، نوتة
"""
import os, math
from PIL import Image, ImageDraw, ImageFilter

OUT = "/home/user/theme-store/public/assets/effects"
os.makedirs(OUT, exist_ok=True)
S = 512
C = S // 2

def new():
    return Image.new("RGBA", (S, S), (0, 0, 0, 0))

def glow_under(img, color, rad=26, alpha=150):
    a = img.split()[3].point(lambda v: min(255, int(v * alpha / 255)))
    g = Image.new("RGBA", (S, S), color + (0,))
    g.putalpha(a)
    g = g.filter(ImageFilter.GaussianBlur(rad))
    return Image.alpha_composite(g, img)

def heart(d, cx, cy, r, color, hi=True):
    d.ellipse([cx - r, cy - r * 0.6, cx, cy + r * 0.4], fill=color)
    d.ellipse([cx, cy - r * 0.6, cx + r, cy + r * 0.4], fill=color)
    d.polygon([(cx - r * 0.97, cy + r * 0.1), (cx + r * 0.97, cy + r * 0.1), (cx, cy + r * 1.25)], fill=color)
    if hi:
        d.ellipse([cx - r * 0.55, cy - r * 0.45, cx - r * 0.12, cy - r * 0.02], fill=(255, 255, 255, 170))

def blossom(d, cx, cy, r, color, center=(245, 196, 81)):
    for k in range(5):
        a = math.radians(k * 72 - 90)
        d.ellipse([cx + r * 0.7 * math.cos(a) - r * 0.52, cy + r * 0.7 * math.sin(a) - r * 0.52,
                   cx + r * 0.7 * math.cos(a) + r * 0.52, cy + r * 0.7 * math.sin(a) + r * 0.52], fill=color)
    d.ellipse([cx - r * 0.26, cy - r * 0.26, cx + r * 0.26, cy + r * 0.26], fill=center)

def star(d, cx, cy, r, color, points=5, inner=0.45, rot=-90):
    pts = []
    for k in range(points * 2):
        a = math.radians(rot + k * 180 / points)
        rr = r if k % 2 == 0 else r * inner
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    d.polygon(pts, fill=color)

def snowf(d, cx, cy, r, color=(240, 250, 255, 255), w=10):
    for k in range(6):
        a = math.radians(k * 60)
        x2, y2 = cx + r * math.cos(a), cy + r * math.sin(a)
        d.line([cx, cy, x2, y2], fill=color, width=w)
        for t in (0.55, 0.8):
            bx, by = cx + r * t * math.cos(a), cy + r * t * math.sin(a)
            for sgn in (-1, 1):
                a2 = a + sgn * math.radians(45)
                d.line([bx, by, bx + r * 0.28 * math.cos(a2), by + r * 0.28 * math.sin(a2)], fill=color, width=w - 3)

ICONS = {}

def icon(fn):
    ICONS[fn.__name__] = fn
    return fn

@icon
def lips(d):
    c = (225, 30, 70, 255)
    d.pieslice([C - 150, C - 90, C, C + 40], 180, 360, fill=c)
    d.pieslice([C, C - 90, C + 150, C + 40], 180, 360, fill=c)
    d.pieslice([C - 150, C - 30, C + 150, C + 150], 0, 180, fill=(190, 20, 60, 255))
    d.line([C - 148, C - 6, C + 148, C - 6], fill=(120, 8, 36, 255), width=8)
    d.ellipse([C - 96, C - 74, C - 40, C - 46], fill=(255, 255, 255, 110))

@icon
def bubble(d):
    d.ellipse([70, 70, S - 70, S - 70], outline=(170, 230, 230, 220), width=10)
    d.ellipse([86, 86, S - 86, S - 86], fill=(140, 210, 210, 40))
    d.ellipse([130, 120, 230, 220], fill=(255, 255, 255, 220))
    d.ellipse([300, 300, 350, 350], fill=(255, 255, 255, 140))
    d.arc([110, 110, S - 110, S - 110], 20, 160, fill=(255, 255, 255, 120), width=8)

@icon
def fire(d):
    pts = [(C, 60), (C + 90, 180), (C + 120, 300), (C + 80, 420), (C, 460), (C - 80, 420), (C - 120, 300), (C - 90, 180)]
    d.polygon(pts, fill=(255, 110, 20, 255))
    d.polygon([(C, 150), (C + 62, 260), (C + 50, 370), (C, 430), (C - 50, 370), (C - 62, 260)], fill=(255, 170, 40, 255))
    d.polygon([(C, 250), (C + 34, 330), (C, 410), (C - 34, 330)], fill=(255, 230, 120, 255))

@icon
def snow(d):
    snowf(d, C, C, 180, (235, 248, 255, 255), 14)
    d.ellipse([C - 26, C - 26, C + 26, C + 26], fill=(255, 255, 255, 255))

@icon
def rose(d):
    for t in range(6, 0, -1):
        col = (196 + (6 - t) * 10, 40 + (6 - t) * 22, 60 + (6 - t) * 24, 255)
        d.ellipse([C - 26 * t, C - 26 * t, C + 26 * t, C + 26 * t], outline=col, width=16)
    d.ellipse([C - 30, C - 30, C + 30, C + 30], fill=(120, 14, 34, 255))
    d.arc([C - 150, C - 150, C + 150, C + 150], 200, 340, fill=(255, 190, 200, 200), width=10)

@icon
def heart_i(d):
    heart(d, C, C - 10, 165, (235, 80, 140, 255))

@icon
def sparkle(d):
    d.polygon([(C, 40), (C + 34, C - 34), (S - 40, C), (C + 34, C + 34), (C, S - 40), (C - 34, C + 34), (40, C), (C - 34, C - 34)], fill=(255, 255, 255, 255))
    d.ellipse([C - 60, C - 60, C + 60, C + 60], fill=(255, 255, 240, 200))
    star(d, 120, 120, 34, (255, 255, 255, 220), 4, 0.3)
    star(d, S - 110, S - 130, 26, (255, 255, 255, 200), 4, 0.3)

@icon
def butterfly(d):
    for sgn in (-1, 1):
        d.ellipse([C + sgn * 150 - 110 if sgn < 0 else C + 40, 90, C + sgn * 150 + 110 if sgn < 0 else C + 260, 290], fill=(186, 120, 230, 235))
        d.ellipse([C + (150 if sgn > 0 else -260), 250, C + (260 if sgn > 0 else -150), 420], fill=(150, 90, 210, 235))
        d.ellipse([C + (170 if sgn > 0 else -215), 140, C + (215 if sgn > 0 else -170), 185], fill=(255, 255, 255, 160))
    d.ellipse([C - 16, 80, C + 16, 430], fill=(70, 40, 90, 255))
    d.line([C - 8, 84, C - 46, 40], fill=(70, 40, 90, 255), width=8)
    d.line([C + 8, 84, C + 46, 40], fill=(70, 40, 90, 255), width=8)

@icon
def leaf(d):
    for i, (cx, cy, ang) in enumerate([(C - 70, C - 40, 35), (C + 70, C - 10, -30), (C - 20, C + 90, 70)]):
        lf = Image.new("RGBA", (300, 150), (0, 0, 0, 0))
        ImageDraw.Draw(lf).ellipse([0, 0, 299, 149], fill=(96, 170, 80, 245))
        ImageDraw.Draw(lf).line([10, 75, 290, 75], fill=(58, 120, 48, 255), width=8)
        lf = lf.rotate(ang, expand=True, resample=Image.BICUBIC)
        d._image.paste(lf, (cx - lf.width // 2, cy - lf.height // 2), lf)

@icon
def star_i(d):
    star(d, C, C, 195, (250, 200, 60, 255))
    star(d, C, C, 120, (255, 232, 130, 255))

@icon
def drop(d):
    d.polygon([(C, 60), (C + 118, 260), (C + 118, 330), (C, 452), (C - 118, 330), (C - 118, 260)], fill=(90, 170, 235, 245))
    d.ellipse([C - 118, 240, C + 118, 452], fill=(90, 170, 235, 245))
    d.ellipse([C - 62, 260, C - 16, 330], fill=(255, 255, 255, 190))

@icon
def sakura(d):
    blossom(d, C, C, 175, (250, 190, 210, 255), (230, 120, 150, 255))

@icon
def moon(d):
    d.ellipse([90, 70, 420, 400], fill=(235, 235, 210, 255))
    d.ellipse([170, 60, 470, 360], fill=(0, 0, 0, 0))
    m = new()
    ImageDraw.Draw(m).ellipse([90, 70, 420, 400], fill=(235, 235, 210, 255))
    cut = new()
    ImageDraw.Draw(cut).ellipse([160, 40, 470, 350], fill=(0, 0, 0, 255))
    m.putalpha(Image.composite(Image.new("L", (S, S), 0), m.split()[3], cut.split()[3]))
    d._image.paste(m, (0, 0), m)
    star(d, 380, 330, 30, (255, 255, 220, 255), 4, 0.35)

@icon
def sun(d):
    d.ellipse([C - 95, C - 95, C + 95, C + 95], fill=(255, 200, 60, 255))
    for k in range(12):
        a = math.radians(k * 30)
        d.polygon([(C + 110 * math.cos(a - 0.14), C + 110 * math.sin(a - 0.14)),
                   (C + 190 * math.cos(a), C + 190 * math.sin(a)),
                   (C + 110 * math.cos(a + 0.14), C + 110 * math.sin(a + 0.14))], fill=(255, 200, 60, 255))
    d.ellipse([C - 40, C - 40, C + 10, C + 10], fill=(255, 240, 170, 220))

@icon
def gem(d):
    pts = [(C, 90), (C + 150, 200), (C + 90, 420), (C - 90, 420), (C - 150, 200)]
    d.polygon(pts, fill=(110, 180, 240, 245))
    d.polygon([pts[0], pts[1], (C, 260)], fill=(190, 230, 255, 255))
    d.polygon([pts[3], pts[4], (C, 260)], fill=(60, 120, 200, 255))
    d.polygon([pts[0], pts[4], (C, 260)], fill=(140, 200, 250, 255))
    d.line([pts[4][0], pts[4][1], pts[1][0], pts[1][1]], fill=(255, 255, 255, 200), width=6)

@icon
def clover(d):
    for k in range(4):
        a = math.radians(k * 90 + 45)
        d.ellipse([C + 95 * math.cos(a) - 78, C + 95 * math.sin(a) - 78,
                   C + 95 * math.cos(a) + 78, C + 95 * math.sin(a) + 78], fill=(90, 170, 70, 245))
    d.line([C, C, C + 40, 440], fill=(70, 140, 55, 255), width=14)

@icon
def feather(d):
    lf = Image.new("RGBA", (460, 200), (0, 0, 0, 0))
    ld = ImageDraw.Draw(lf)
    ld.ellipse([0, 0, 459, 199], fill=(240, 200, 220, 240))
    for x in range(40, 440, 34):
        ld.line([x, 20, x - 26, 100], fill=(210, 160, 190, 255), width=6)
        ld.line([x, 180, x - 26, 100], fill=(210, 160, 190, 255), width=6)
    ld.line([10, 100, 450, 100], fill=(255, 255, 255, 220), width=8)
    lf = lf.rotate(-35, expand=True, resample=Image.BICUBIC)
    d._image.paste(lf, (C - lf.width // 2, C - lf.height // 2), lf)

@icon
def bolt(d):
    d.polygon([(280, 40), (150, 280), (240, 280), (190, 470), (370, 220), (270, 220), (340, 40)], fill=(255, 220, 60, 255))
    d.polygon([(285, 90), (200, 260), (255, 260), (225, 400), (330, 240), (265, 240), (315, 90)], fill=(255, 246, 170, 255))

@icon
def cloud(d):
    d.ellipse([90, 200, 280, 360], fill=(250, 250, 255, 245))
    d.ellipse([180, 130, 380, 310], fill=(250, 250, 255, 245))
    d.ellipse([280, 200, 440, 360], fill=(250, 250, 255, 245))
    d.rectangle([120, 280, 400, 356], fill=(250, 250, 255, 245))
    d.ellipse([150, 170, 230, 240], fill=(255, 255, 255, 200))

@icon
def cherry(d):
    d.ellipse([110, 280, 250, 420], fill=(210, 40, 60, 255))
    d.ellipse([270, 300, 400, 430], fill=(180, 26, 48, 255))
    d.arc([150, 60, 330, 330], 200, 340, fill=(90, 140, 60, 255), width=14)
    d.arc([230, 70, 420, 350], 200, 340, fill=(90, 140, 60, 255), width=14)
    lf = Image.new("RGBA", (160, 80), (0, 0, 0, 0))
    ImageDraw.Draw(lf).ellipse([0, 0, 159, 79], fill=(110, 170, 80, 255))
    lf = lf.rotate(30, expand=True, resample=Image.BICUBIC)
    d._image.paste(lf, (250, 60), lf)
    d.ellipse([140, 310, 190, 360], fill=(255, 255, 255, 150))

@icon
def hearts2(d):
    heart(d, C - 80, C - 40, 110, (240, 110, 160, 255))
    heart(d, C + 80, C + 40, 130, (225, 60, 110, 255))

@icon
def pearl(d):
    d.ellipse([110, 110, 402, 402], fill=(246, 242, 236, 255))
    d.ellipse([110, 110, 402, 402], outline=(206, 196, 180, 255), width=6)
    d.ellipse([170, 150, 260, 240], fill=(255, 255, 255, 255))
    d.arc([150, 150, 370, 370], 20, 160, fill=(255, 255, 255, 140), width=10)

@icon
def crown(d):
    d.polygon([(110, 380), (110, 200), (180, 280), (256, 150), (332, 280), (402, 200), (402, 380)], fill=(250, 200, 60, 255))
    d.rectangle([110, 350, 402, 402], fill=(230, 170, 40, 255))
    for gx in (110, 256, 402):
        d.ellipse([gx - 22, 128 if gx == 256 else 178, gx + 22, 172 if gx == 256 else 222], fill=(255, 230, 140, 255))
    for gx in (170, 256, 342):
        d.ellipse([gx - 16, 358, gx + 16, 390], fill=(225, 80, 120, 255))

@icon
def note(d):
    d.ellipse([120, 330, 240, 430], fill=(180, 120, 230, 255))
    d.ellipse([280, 300, 400, 400], fill=(180, 120, 230, 255))
    d.rectangle([228, 120, 252, 380], fill=(180, 120, 230, 255))
    d.rectangle([388, 90, 412, 350], fill=(180, 120, 230, 255))
    d.polygon([(228, 120), (412, 90), (412, 150), (228, 180)], fill=(180, 120, 230, 255))

GLOW = {
    "lips": (255, 60, 110), "bubble": (120, 220, 220), "fire": (255, 120, 30), "snow": (160, 210, 255),
    "rose": (255, 70, 100), "heart_i": (255, 90, 150), "sparkle": (255, 250, 200), "butterfly": (190, 130, 240),
    "leaf": (120, 200, 100), "star_i": (255, 210, 80), "drop": (110, 180, 250), "sakura": (250, 170, 200),
    "moon": (240, 240, 200), "sun": (255, 200, 70), "gem": (120, 190, 250), "clover": (110, 190, 90),
    "feather": (240, 190, 215), "bolt": (255, 225, 90), "cloud": (200, 210, 250), "cherry": (230, 60, 80),
    "hearts2": (250, 100, 150), "pearl": (240, 235, 220), "crown": (250, 200, 70), "note": (190, 130, 240),
}

for name, fn in ICONS.items():
    img = new()
    d = ImageDraw.Draw(img)
    d._image = img
    fn(d)
    img = glow_under(img, GLOW[name])
    img.save(os.path.join(OUT, f"fx-{name}.png"), optimize=True)
print("تم توليد", len(ICONS), "أيقونة تأثير في assets/effects/")
