# -*- coding: utf-8 -*-
"""
مولّد الأزرار الموحّد — ثيماتي (الإصدار 3)
133 زراً بدقة 448×616 بهوية مستقلة لكل مجموعة:
- لامع: زر ناعم بحواف خفيفة رفيعة ولمعة واسعة (بلا إطارات ثريدي عريضة)
- مجوهرات: لوحة مثمنة الأضلاع بإطار معدني مذهّب وجواهر
- إطار أنيق: إطار خطي مزدوج بزوايا محفورة
- إطارات فاخرة أ: عقد لؤلؤ محيطي وزهور
- إطارات فاخرة ب: غار جانبي + تاج/شمس مع جسم معتّم
- توليد فردي: لمعة قطرية وزخارف مرحة متنوعة
"""
import os, json, math
from PIL import Image, ImageDraw, ImageFilter

PUB = "/home/user/theme-store/public"
BTN = os.path.join(PUB, "assets", "buttons")

s = open(os.path.join(PUB, "assets", "data.js"), encoding="utf-8").read()
DATA = json.loads(s[len("window.LIB = "):-2])

W, H = 448, 616
GOLD = (212, 160, 23)
GOLD_L = (250, 214, 120)
GOLD_D = (140, 96, 10)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

def hx(t): return "#%02x%02x%02x" % tuple(t)
def px(h): return tuple(int(h[i:i+2], 16) for i in (1, 3, 5))
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def shade(c, f): return tuple(min(255, int(v * f)) for v in c)

def vgrad(w, h, stops):
    img = Image.new("RGB", (w, h))
    p = img.load()
    for y in range(h):
        t = y / max(h - 1, 1)
        c = stops[-1][1]
        for i in range(len(stops) - 1):
            p0, c0 = stops[i]; p1, c1 = stops[i + 1]
            if t <= p1:
                lt = 0 if p1 == p0 else min(max((t - p0) / (p1 - p0), 0), 1)
                c = mix(c0, c1, lt)
                break
        for x in range(w): p[x, y] = c
    return img

def rmask(w, h, r):
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=255)
    return m

def omask(w, h, cut):
    """قناع مثمن الأضلاع (زوايا مقصوصة) لمجموعة المجوهرات."""
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).polygon([(cut, 0), (w - cut, 0), (w, cut), (w, h - cut),
                               (w - cut, h), (cut, h), (0, h - cut), (0, cut)], fill=255)
    return m

# ---------------- عناصر الزخرفة ----------------
def gem(d, cx, cy, r, color):
    pts = [(cx, cy - r), (cx + r * 0.8, cy), (cx, cy + r), (cx - r * 0.8, cy)]
    d.polygon(pts, fill=mix(color, WHITE, 0.15))
    d.polygon([pts[0], pts[1], (cx, cy)], fill=mix(color, WHITE, 0.55))
    d.polygon([pts[2], pts[3], (cx, cy)], fill=shade(color, 0.6))
    d.ellipse([cx - r * 0.18, cy - r * 0.35, cx + r * 0.18, cy - r * 0.05], fill=(255, 255, 255, 200))

def pearl(d, cx, cy, r):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(246, 242, 234))
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(196, 186, 168), width=2)
    d.ellipse([cx - r * 0.45, cy - r * 0.55, cx - r * 0.05, cy - r * 0.15], fill=WHITE)

def leaf(d, cx, cy, ln, ang, color):
    lf = Image.new("RGBA", (ln * 2, ln), (0, 0, 0, 0))
    ImageDraw.Draw(lf).ellipse([0, 0, ln * 2 - 1, ln - 1], fill=color)
    lf = lf.rotate(ang, expand=True, resample=Image.BICUBIC)
    return lf, (cx - lf.width // 2, cy - lf.height // 2)

def snow(d, cx, cy, r, color=WHITE):
    for k in range(6):
        a = math.radians(k * 60)
        d.line([cx, cy, cx + r * math.cos(a), cy + r * math.sin(a)], fill=color, width=3)
        bx, by = cx + r * 0.55 * math.cos(a), cy + r * 0.55 * math.sin(a)
        for sgn in (-1, 1):
            a2 = a + sgn * math.radians(45)
            d.line([bx, by, bx + r * 0.3 * math.cos(a2), by + r * 0.3 * math.sin(a2)], fill=color, width=2)

def crown(d, cx, cy, w_):
    h_ = w_ * 0.7
    d.polygon([(cx - w_/2, cy + h_/2), (cx - w_/2, cy - h_/4), (cx - w_/4, cy + h_/8),
               (cx, cy - h_/2), (cx + w_/4, cy + h_/8), (cx + w_/2, cy - h_/4), (cx + w_/2, cy + h_/2)],
              fill=GOLD_L, outline=GOLD_D)
    for gx in (-w_/2, 0, w_/2):
        d.ellipse([cx + gx - 4, cy - h_/2 - 6, cx + gx + 4, cy - h_/2 + 2], fill=GOLD_L)

def sun(d, cx, cy, r):
    d.ellipse([cx - r * 0.45, cy - r * 0.45, cx + r * 0.45, cy + r * 0.45], fill=GOLD_L, outline=GOLD_D)
    for k in range(8):
        a = math.radians(k * 45 + 22)
        d.polygon([(cx + r * 0.5 * math.cos(a - 0.18), cy + r * 0.5 * math.sin(a - 0.18)),
                   (cx + r * math.cos(a), cy + r * math.sin(a)),
                   (cx + r * 0.5 * math.cos(a + 0.18), cy + r * 0.5 * math.sin(a + 0.18))], fill=GOLD_L)

def heart(d, cx, cy, r, color):
    d.ellipse([cx - r, cy - r * 0.6, cx, cy + r * 0.4], fill=color)
    d.ellipse([cx, cy - r * 0.6, cx + r, cy + r * 0.4], fill=color)
    d.polygon([(cx - r * 0.97, cy + r * 0.1), (cx + r * 0.97, cy + r * 0.1), (cx, cy + r * 1.25)], fill=color)
    d.ellipse([cx - r * 0.55, cy - r * 0.45, cx - r * 0.15, cy - r * 0.05], fill=mix(color, WHITE, 0.6))

def bow(d, cx, cy, w_, color):
    h_ = w_ * 0.5
    d.polygon([(cx, cy), (cx - w_, cy - h_), (cx - w_ * 0.85, cy + h_)], fill=color)
    d.polygon([(cx, cy), (cx + w_, cy - h_), (cx + w_ * 0.85, cy + h_)], fill=color)
    d.ellipse([cx - w_ * 0.18, cy - h_ * 0.5, cx + w_ * 0.18, cy + h_ * 0.5], fill=mix(color, WHITE, 0.35))

def blossom(d, cx, cy, r, color=(255, 250, 245)):
    for k in range(5):
        a = math.radians(k * 72 - 90)
        d.ellipse([cx + r * 0.7 * math.cos(a) - r * 0.5, cy + r * 0.7 * math.sin(a) - r * 0.5,
                   cx + r * 0.7 * math.cos(a) + r * 0.5, cy + r * 0.7 * math.sin(a) + r * 0.5], fill=color)
    d.ellipse([cx - r * 0.28, cy - r * 0.28, cx + r * 0.28, cy + r * 0.28], fill=(245, 196, 81))

def star4(d, cx, cy, r, color):
    d.polygon([(cx, cy - r), (cx + r * 0.28, cy - r * 0.28), (cx + r, cy), (cx + r * 0.28, cy + r * 0.28),
               (cx, cy + r), (cx - r * 0.28, cy + r * 0.28), (cx - r, cy), (cx - r * 0.28, cy - r * 0.28)], fill=color)

def filigree(d, x0, y0, x1, y1, color=GOLD):
    for (cx, cy) in [(x0, y0), (x1, y0), (x0, y1), (x1, y1)]:
        d.arc([cx - 22, cy - 22, cx + 22, cy + 22], start=0, end=360, fill=color, width=3)
        d.ellipse([cx - 5, cy - 5, cx + 5, cy + 5], fill=GOLD_L)

# ---------------- هوية كل مجموعة ----------------
SET_STYLE = {
    #            نصف قطر الجسم، توقفات التدرج،          نصف قطر اللوحة، شكل اللوحة
    "glossy":     dict(r=76, stops=(0.20, 0.16), pr=46, shape="round"),   # ناعم بحواف خفيفة
    "jewel":      dict(r=56, stops=(0.42, 0.55), pr=0,  shape="oct"),     # مثمن معدني
    "frame":      dict(r=34, stops=(0.28, 0.34), pr=22, shape="round"),   # خطي حاد
    "newframe-a": dict(r=64, stops=(0.36, 0.28), pr=48, shape="round"),   # لؤلؤي
    "newframe-b": dict(r=44, stops=(0.26, 0.48), pr=28, shape="round"),   # معتّم ملكي
    "solo":       dict(r=84, stops=(0.32, 0.38), pr=58, shape="round"),   # حبة دواء مرحة
}

def set_motif(setid, i):
    if setid == "glossy":     return "plain"
    if setid == "jewel":      return "gems"
    if setid == "frame":      return ["filigree", "onyx"][i % 2]
    if setid == "newframe-a": return ["pearl", "blossom"][i % 2]
    if setid == "newframe-b": return ["laurel", "crown", "laurel", "sun"][i % 4]
    return ["bow", "hearts", "stars", "snow", "blossom", "sun"][i % 6]   # solo

# ---------------- بناء الزر ----------------
def build_button(pal, setid, idx):
    base, dark, light = px(pal["base"]), px(pal["dark"]), px(pal["light"])
    st = SET_STYLE[setid]
    motif = set_motif(setid, idx)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))

    # ظل خارجي ناعم
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([16, 24, W - 16, H - 12], radius=st["r"], fill=(0, 0, 0, 95))
    sh = sh.filter(ImageFilter.GaussianBlur(11))
    img = Image.alpha_composite(img, sh)

    # جسم الزر بتدرج يخص المجموعة (الناعمة بتباين خفيف = حواف رفيعة)
    hi, lo = st["stops"]
    body = vgrad(W, H, [(0, mix(base, WHITE, hi)), (0.5, base), (1, mix(base, BLACK, lo))])
    img.paste(body, (0, 0), rmask(W, H, st["r"]))
    d = ImageDraw.Draw(img)

    # الحافة الخارجية: رفيعة وفاتحة للناعمة، ومميزة لكل مجموعة
    if setid == "glossy":
        d.rounded_rectangle([7, 9, W - 8, H - 8], radius=st["r"] - 3, outline=mix(base, WHITE, 0.55), width=2)
        d.rounded_rectangle([12, 14, W - 13, H - 13], radius=st["r"] - 7, outline=mix(base, BLACK, 0.10), width=1)
    elif setid == "jewel":
        d.rounded_rectangle([9, 11, W - 10, H - 10], radius=st["r"], outline=GOLD, width=5)
        d.rounded_rectangle([17, 19, W - 18, H - 18], radius=st["r"] - 8, outline=GOLD_D, width=2)
    elif setid == "frame":
        d.rounded_rectangle([9, 11, W - 10, H - 10], radius=st["r"], outline=shade(base, 0.5), width=3)
    elif setid == "newframe-a":
        d.rounded_rectangle([9, 11, W - 10, H - 10], radius=st["r"], outline=mix(base, WHITE, 0.6), width=3)
    elif setid == "newframe-b":
        d.rounded_rectangle([9, 11, W - 10, H - 10], radius=st["r"], outline=shade(base, 0.42), width=4)
    else:
        d.rounded_rectangle([9, 11, W - 10, H - 10], radius=st["r"], outline=mix(base, BLACK, 0.22), width=3)

    # اللمعة العلوية: واسعة ناعمة للناعمة، وقطرية لـ solo
    gloss = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(gloss)
    if setid == "solo":
        gd.polygon([(60, 0), (200, 0), (90, H), (0, H), (0, 300)], fill=(255, 255, 255, 46))
    elif setid == "glossy":
        gd.ellipse([30, -H * 0.30, W - 30, H * 0.40], fill=(255, 255, 255, 82))
    else:
        gd.ellipse([46, -H * 0.26, W - 46, H * 0.30], fill=(255, 255, 255, 58))
    gloss = gloss.filter(ImageFilter.GaussianBlur(16 if setid == "glossy" else 12))
    img = Image.alpha_composite(img, gloss)
    d = ImageDraw.Draw(img)

    # لوحة المركز الفارغة — شكل يخص المجموعة
    ci = 58
    pw, ph = W - ci * 2, H - ci * 2
    panel = vgrad(pw, ph, [(0, mix(base, WHITE, 0.52)), (1, mix(base, WHITE, 0.34))])
    if st["shape"] == "oct":
        pm = omask(pw, ph, 52)
        img.paste(panel, (ci, ci), pm)
        d = ImageDraw.Draw(img)
        d.line([(ci + 52, ci), (W - ci - 52, ci)], fill=GOLD, width=3)
        d.line([(ci + 52, H - ci), (W - ci - 52, H - ci)], fill=GOLD, width=3)
        d.line([(ci, ci + 52), (ci, H - ci - 52)], fill=GOLD, width=3)
        d.line([(W - ci, ci + 52), (W - ci, H - ci - 52)], fill=GOLD, width=3)
    else:
        img.paste(panel, (ci, ci), rmask(pw, ph, st["pr"]))
        d = ImageDraw.Draw(img)
        if setid == "glossy":   # تحديد خفيف جداً بلا حواف ثريدي
            d.rounded_rectangle([ci, ci, W - ci - 1, H - ci - 1], radius=st["pr"], outline=mix(base, BLACK, 0.10), width=2)
        elif setid == "frame":  # خط مزدوج مذهّب رفيع
            d.rounded_rectangle([ci, ci, W - ci - 1, H - ci - 1], radius=st["pr"], outline=shade(base, 0.5), width=3)
            d.rounded_rectangle([ci + 7, ci + 7, W - ci - 8, H - ci - 8], radius=st["pr"] - 5, outline=GOLD, width=2)
        elif setid == "newframe-a":
            d.rounded_rectangle([ci, ci, W - ci - 1, H - ci - 1], radius=st["pr"], outline=mix(base, WHITE, 0.65), width=2)
        elif setid == "newframe-b":
            d.rounded_rectangle([ci, ci, W - ci - 1, H - ci - 1], radius=st["pr"], outline=mix(base, BLACK, 0.30), width=3)
            d.arc([ci + 20, ci + 10, W - ci - 20, ci + 150], start=180, end=360, fill=mix(base, WHITE, 0.5), width=2)
        else:
            d.rounded_rectangle([ci, ci, W - ci - 1, H - ci - 1], radius=st["pr"], outline=mix(base, WHITE, 0.5), width=2)

    # ---- الزخرفة على الإطار فقط ----
    bx0, by0, bx1, by1 = 30, 36, W - 30, H - 36
    cx, cy = W // 2, H // 2
    gemc = base
    if motif == "gems":
        d.rounded_rectangle([bx0 - 4, by0 - 4, bx1 + 4, by1 + 4], radius=48, outline=GOLD, width=3)
        gem(d, cx, by0 + 2, 27, gemc); gem(d, cx, by1 - 2, 27, gemc)
        for (gx, gy) in [(bx0 + 6, by0 + 8), (bx1 - 6, by0 + 8), (bx0 + 6, by1 - 8), (bx1 - 6, by1 - 8)]:
            gem(d, gx, gy, 16, gemc)
    elif motif == "pearl":
        for yy in range(by0 + 10, by1 - 4, 34):
            pearl(d, bx0 + 4, yy, 12); pearl(d, bx1 - 4, yy, 12)
        for xx in range(bx0 + 30, bx1 - 12, 34):
            pearl(d, xx, by0 + 2, 10); pearl(d, xx, by1 - 2, 10)
    elif motif == "blossom" and setid == "newframe-a":
        for (gx, gy) in [(bx0 + 16, by0 + 16), (bx1 - 16, by0 + 16), (bx0 + 16, by1 - 16), (bx1 - 16, by1 - 16)]:
            blossom(d, gx, gy, 20)
        for yy in range(by0 + 52, by1 - 30, 46):
            pearl(d, bx0 + 4, yy, 9); pearl(d, bx1 - 4, yy, 9)
    elif motif == "laurel":
        for yy in range(by0 + 26, by1 - 10, 44):
            for side, sgn in ((bx0 + 8, 1), (bx1 - 8, -1)):
                lf, pos = leaf(d, side, yy, 21, 35 * sgn, GOLD)
                img.paste(lf, pos, lf)
        d = ImageDraw.Draw(img)
        gem(d, cx, by0 + 2, 19, gemc); gem(d, cx, by1 - 2, 19, gemc)
    elif motif == "crown":
        crown(d, cx, by0 + 8, 66)
        for xx in range(bx0 + 16, bx1 - 4, 40):
            pearl(d, xx, by1 - 4, 10)
    elif motif == "sun":
        for (gx, gy) in [(bx0 + 16, by0 + 16), (bx1 - 16, by0 + 16), (bx0 + 16, by1 - 16), (bx1 - 16, by1 - 16)]:
            sun(d, gx, gy, 21)
    elif motif == "hearts":
        heart(d, cx, by0 + 10, 17, gemc); heart(d, cx, by1 - 12, 17, gemc)
        for yy in range(by0 + 40, by1 - 24, 40):
            pearl(d, bx0 + 4, yy, 9); pearl(d, bx1 - 4, yy, 9)
    elif motif == "bow":
        bow(d, cx, by0 + 10, 38, gemc)
        heart(d, cx, by1 - 12, 14, gemc)
        for yy in range(by0 + 36, by1 - 20, 36):
            pearl(d, bx0 + 4, yy, 10); pearl(d, bx1 - 4, yy, 10)
    elif motif == "stars":
        for (gx, gy) in [(bx0 + 14, by0 + 14), (bx1 - 14, by0 + 14), (bx0 + 14, by1 - 14), (bx1 - 14, by1 - 14)]:
            star4(d, gx, gy, 17, GOLD_L)
        star4(d, cx, by0 + 5, 13, WHITE)
    elif motif == "snow":
        for (gx, gy) in [(bx0 + 16, by0 + 16), (bx1 - 16, by0 + 16), (bx0 + 16, by1 - 16), (bx1 - 16, by1 - 16)]:
            snow(d, gx, gy, 19)
        snow(d, cx, by0 + 4, 14); snow(d, cx, by1 - 4, 14)
    elif motif == "filigree":
        d.rounded_rectangle([bx0 - 2, by0 - 2, bx1 + 2, by1 + 2], radius=44, outline=GOLD, width=2)
        filigree(d, bx0 + 12, by0 + 12, bx1 - 12, by1 - 12)
    elif motif == "onyx":
        d.rounded_rectangle([bx0 - 2, by0 - 2, bx1 + 2, by1 + 2], radius=44, outline=GOLD_L, width=3)
        for (gx, gy) in [(bx0 + 10, by0 + 10), (bx1 - 10, by0 + 10), (bx0 + 10, by1 - 10), (bx1 - 10, by1 - 10)]:
            d.polygon([(gx, gy - 8), (gx + 8, gy), (gx, gy + 8), (gx - 8, gy)], fill=GOLD_L)
    return img

for b in DATA["buttons"]:
    idx = int(b["id"].split("-")[-1])
    img = build_button(b["palette"], b["set"], idx)
    img.save(os.path.join(BTN, f"btn-{b['id']}.png"), optimize=True)
print("تم توليد", len(DATA["buttons"]), "زراً بهوية مستقلة لكل مجموعة بدقة 448×616")
