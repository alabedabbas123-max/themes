# -*- coding: utf-8 -*-
"""
مولّد ملفات الفهرس JSON — ثيماتي
downloads/json/buttons.json      ← فهرس الأزرار (تحميل زر واحد عند الاختيار)
downloads/json/backgrounds.json  ← فهرس الخلفيات
downloads/json/effects.json      ← فهرس التأثيرات (تحميل تأثير واحد عند الاختيار)
downloads/json/themes.json       ← كل الثيمات ببياناتها الكاملة
downloads/json/theme-sets.json   ← أقسام الثيمات مجمعة (اختيار قسم → ثيماته)
"""
import os, json, datetime
PUB = "/home/user/theme-store/public"
OUT = os.path.join(PUB, "downloads", "json")
os.makedirs(OUT, exist_ok=True)

s = open(os.path.join(PUB, "assets", "data.js"), encoding="utf-8").read()
D = json.loads(s[len("window.LIB = "):-2])

def px(h): return tuple(int(h[i:i+2], 16) for i in (1, 3, 5))
def mix(a, b, t): return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))
def hx(c): return "#%02x%02x%02x" % tuple(max(0, min(255, int(v))) for v in c)
def rel(c):
    f = lambda v: (v / 255) / 12.92 if v / 255 <= 0.03928 else ((v / 255 + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2])
def ratio(a, b):
    l1, l2 = rel(a), rel(b); return (max(l1, l2) + 0.05) / (min(l1, l2) + 0.05)

def audit(pal, bgLum):
    base, dark, light = px(pal["base"]), px(pal["dark"]), px(pal["light"])
    panel = mix(base, (255, 255, 255), 0.43); pl = 0.299*panel[0] + 0.587*panel[1] + 0.114*panel[2]
    kc = dark if pl > 150 else mix(light, (255, 255, 255), 0.45)
    if ratio(kc, panel) < 3: kc = (20, 16, 24) if pl > 150 else (255, 255, 255)
    eff = (bgLum or 120) * 0.7 + 12 * 0.3
    approx = (235, 235, 235) if eff > 140 else (22, 18, 26)
    bar = dark if eff > 140 else mix(light, (255, 255, 255), 0.5)
    if ratio(bar, approx) < 3: bar = (26, 20, 30) if eff > 140 else (255, 255, 255)
    return hx(kc), hx(bar)

NOW = datetime.datetime.now().isoformat(timespec="seconds")
META = {"app": "ثيماتي", "version": 3, "generatedAt": NOW}

# 1) الأزرار
json.dump({**META, "kind": "buttons", "count": len(D["buttons"]),
           "sets": D["sets"],
           "items": [{"id": b["id"], "set": b["set"], "setAr": b["setAr"], "colorAr": b["colorAr"],
                      "name": b["name"], "src": b["src"], "palette": b["palette"], "bgLum": b.get("bgLum")}
                     for b in D["buttons"]]},
          open(f"{OUT}/buttons.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# 2) الخلفيات
json.dump({**META, "kind": "backgrounds", "count": len(D["backgrounds"]),
           "items": [{"id": g["id"], "name": g["name"], "src": g["src"], "forButton": g["forButton"],
                      "palette": g["palette"]} for g in D["backgrounds"]]},
          open(f"{OUT}/backgrounds.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# 3) التأثيرات
json.dump({**META, "kind": "effects", "count": len(D["effects"]),
           "items": [{"id": e["id"], "name": e["name"], "tag": e["tag"], "desc": e["desc"],
                      "icon": e["icon"], **({"css": e["css"], "zip": e["zip"]} if e.get("css") else {})}
                     for e in D["effects"]]},
          open(f"{OUT}/effects.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# 4) الثيمات الكاملة
themes = []
for b in D["buttons"]:
    kt, bt = audit(b["palette"], b.get("bgLum"))
    themes.append({"id": b["id"], "name": f"ثيم {b['name']}", "set": b["set"], "setAr": b["setAr"],
                   "button": {"name": b["name"], "src": b["src"]},
                   "background": {"src": f"assets/backgrounds/bg-{b['id']}.jpg"},
                   "css": b["css"],
                   "colors": {"base": b["palette"]["base"], "dark": b["palette"]["dark"],
                              "light": b["palette"]["light"], "text": kt, "toolbarText": bt}})
json.dump({**META, "kind": "themes", "count": len(themes), "items": themes},
          open(f"{OUT}/themes.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# 5) أقسام الثيمات مجمعة
sets = []
for sdef in D["sets"]:
    items = [t for t in themes if t["set"] == sdef["id"]]
    sets.append({"id": sdef["id"], "ar": sdef["ar"], "count": len(items), "themes": items})
json.dump({**META, "kind": "theme-sets", "count": len(sets), "sets": sets},
          open(f"{OUT}/theme-sets.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

print("تم توليد 5 ملفات JSON في downloads/json/")
