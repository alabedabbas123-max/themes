# -*- coding: utf-8 -*-
"""يحزم المشروع كاملاً في public/downloads/thematy-project.zip"""
import os, zipfile

ROOT = "/home/user/theme-store"
OUT = os.path.join(ROOT, "public", "downloads", "thematy-project.zip")
SKIP = {"thematy-project.zip", "__pycache__"}

n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for dirpath, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in SKIP]
        for f in files:
            if f in SKIP:
                continue
            full = os.path.join(dirpath, f)
            rel = os.path.relpath(full, ROOT)
            z.write(full, "thematy/" + rel)
            n += 1
print(f"تم حزم {n} ملفاً → {OUT} ({os.path.getsize(OUT)/1e6:.1f} MB)")
