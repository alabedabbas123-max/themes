# -*- coding: utf-8 -*-
"""
مولّد الإضافات — ثيماتي
4 مجموعات أزرار جديدة (12 لكل منها = 48): زجاج شفاف، حواف زهرية، حواف خشبية، إطارات طبيعية
+ خلفيات 720×1280 من 6 عائلات مشهدية: طبيعة، مشاهير(مسرح ذهبي)، رومانسي، ورود جورية، ثلوج، زهور
+ تحديث data.js وملفات theme.css للعناصر الجديدة
"""
import os, json, math, random
from PIL import Image, ImageDraw, ImageFilter

PUB = "/home/user/theme-store/public"
BTN = os.path.join(PUB, "assets", "buttons")
BGD = os.path.join(PUB, "assets", "backgrounds")
CSS = os.path.join(PUB, "assets", "themes-css")
random.seed(7)

W, H = 448, 616
BW, BH = 720, 1280
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

def px(h): return tuple(int(h[i:i+2], 16) for i in (1, 3, 5))
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def hx(c): return "#%02x%02x%02x" % tuple(c)

def vgrad(w, h, stops):
    img = Image.new("RGB", (w, h))
    p = img.load()
    for y in range(h):
        t = y / max(h - 1, 1)
        c = stops[-1][1]
        for i in range(len(stops) - 1):
            p0, c0 = stops[i]; p1, c1 = stops[i + 1]
            if t <= p1:
                lt = 0 if p1 == p0 else min(max((t - p0) / (p1 - p0), 0), 1)
                c = mix(c0, c1, lt)
                break
        for x in range(w): p[x, y] = c
    return img

def rmask(w, h, r):
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=255)
    return m

def blossom(d, cx, cy, r, color=(255, 250, 245), center=(245, 196, 81)):
    for k in range(5):
        a = math.radians(k * 72 - 90)
        d.ellipse([cx + r * 0.7 * math.cos(a) - r * 0.5, cy + r * 0.7 * math.sin(a) - r * 0.5,
                   cx + r * 0.7 * math.cos(a) + r * 0.5, cy + r * 0.7 * math.sin(a) + r * 0.5], fill=color)
    d.ellipse([cx - r * 0.28, cy - r * 0.28, cx + r * 0.28, cy + r * 0.28], fill=center)

def leafsh(d, cx, cy, ln, ang, color):
    lf = Image.new("RGBA", (ln * 2, ln), (0, 0, 0, 0))
    ImageDraw.Draw(lf).ellipse([0, 0, ln * 2 - 1, ln - 1], fill=color)
    lf = lf.rotate(ang, expand=True, resample=Image.BICUBIC)
    return lf, (cx - lf.width // 2, cy - lf.height // 2)

def star4(d, cx, cy, r, color):
    d.polygon([(cx, cy - r), (cx + r * 0.28, cy - r * 0.28), (cx + r, cy), (cx + r * 0.28, cy + r * 0.28),
               (cx, cy + r), (cx - r * 0.28, cy + r * 0.28), (cx - r, cy), (cx - r * 0.28, cy - r * 0.28)], fill=color)

def snowf(d, cx, cy, r, color=WHITE):
    for k in range(6):
        a = math.radians(k * 60)
        d.line([cx, cy, cx + r * math.cos(a), cy + r * math.sin(a)], fill=color, width=3)
        bx, by = cx + r * 0.55 * math.cos(a), cy + r * 0.55 * math.sin(a)
        for sgn in (-1, 1):
            a2 = a + sgn * math.radians(45)
            d.line([bx, by, bx + r * 0.3 * math.cos(a2), by + r * 0.3 * math.sin(a2)], fill=color, width=2)

def heartsh(d, cx, cy, r, color):
    d.ellipse([cx - r, cy - r * 0.6, cx, cy + r * 0.4], fill=color)
    d.ellipse([cx, cy - r * 0.6, cx + r, cy + r * 0.4], fill=color)
    d.polygon([(cx - r * 0.97, cy + r * 0.1), (cx + r * 0.97, cy + r * 0.1), (cx, cy + r * 1.25)], fill=color)

# ================= الأزرار =================
def btn_glass(pal):
    """زر زجاجي شفاف أنيق"""
    base, dark, light = px(pal["base"]), px(pal["dark"]), px(pal["light"])
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([16, 24, W - 16, H - 12], radius=70, fill=(0, 0, 0, 80))
    img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(12)))
    body = vgrad(W, H, [(0, mix(base, WHITE, 0.55)), (0.5, mix(base, WHITE, 0.25)), (1, mix(base, WHITE, 0.40))])
    ba = body.convert("RGBA")
    ba.putalpha(rmask(W, H, 70).point(lambda v: int(v * 0.62)))   # شفافية زجاجية
    img = Image.alpha_composite(img, ba)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([8, 10, W - 9, H - 9], radius=68, outline=(255, 255, 255, 210), width=3)
    d.rounded_rectangle([16, 18, W - 17, H - 17], radius=62, outline=(255, 255, 255, 110), width=1)
    shine = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(shine).polygon([(90, 0), (210, 0), (60, H), (0, H), (0, 380)], fill=(255, 255, 255, 70))
    ImageDraw.Draw(shine).ellipse([60, -H * 0.2, W - 60, H * 0.28], fill=(255, 255, 255, 90))
    img = Image.alpha_composite(img, shine.filter(ImageFilter.GaussianBlur(10)))
    d = ImageDraw.Draw(img)
    ci = 62
    pm = rmask(W - ci * 2, H - ci * 2, 44).point(lambda v: int(v * 0.5))
    panel = Image.new("RGBA", (W - ci * 2, H - ci * 2), (255, 255, 255, 0))
    panel.paste(vgrad(W - ci * 2, H - ci * 2, [(0, mix(base, WHITE, 0.7)), (1, mix(base, WHITE, 0.5))]), (0, 0),
                rmask(W - ci * 2, H - ci * 2, 44))
    panel.putalpha(pmask := rmask(W - ci * 2, H - ci * 2, 44).point(lambda v: int(v * 0.55)))
    img.paste(panel, (ci, ci), panel)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([ci, ci, W - ci - 1, H - ci - 1], radius=44, outline=(255, 255, 255, 160), width=2)
    for (gx, gy, gr) in [(46, 52, 14), (W - 46, 52, 10), (46, H - 52, 10), (W - 46, H - 52, 14)]:
        star4(d, gx, gy, gr, (255, 255, 255, 220))
    return img

def btn_floral(pal):
    """زر بحواف زهرية أنيقة"""
    base, dark, light = px(pal["base"]), px(pal["dark"]), px(pal["light"])
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([16, 24, W - 16, H - 12], radius=64, fill=(0, 0, 0, 95))
    img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(11)))
    body = vgrad(W, H, [(0, mix(base, WHITE, 0.34)), (0.5, base), (1, mix(base, BLACK, 0.26))])
    img.paste(body, (0, 0), rmask(W, H, 64))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([9, 11, W - 10, H - 10], radius=62, outline=mix(base, WHITE, 0.55), width=3)
    gloss = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(gloss).ellipse([46, -H * 0.26, W - 46, H * 0.32], fill=(255, 255, 255, 66))
    img = Image.alpha_composite(img, gloss.filter(ImageFilter.GaussianBlur(14)))
    d = ImageDraw.Draw(img)
    ci = 60
    img.paste(vgrad(W - ci * 2, H - ci * 2, [(0, mix(base, WHITE, 0.55)), (1, mix(base, WHITE, 0.38))]),
              (ci, ci), rmask(W - ci * 2, H - ci * 2, 40))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([ci, ci, W - ci - 1, H - ci - 1], radius=40, outline=mix(base, WHITE, 0.6), width=2)
    # إطار زهري: وردات وبتلات على المحيط
    bx0, by0, bx1, by1 = 32, 38, W - 32, H - 38
    for xx in range(bx0 + 6, bx1 - 4, 52):
        blossom(d, xx, by0 + 4, 15, (255, 236, 244), (233, 150, 122))
        blossom(d, xx + 26, by1 - 4, 15, (255, 236, 244), (233, 150, 122))
    for yy in range(by0 + 30, by1 - 16, 52):
        blossom(d, bx0 + 4, yy, 15, (252, 226, 236), (233, 150, 122))
        blossom(d, bx1 - 4, yy + 26, 15, (252, 226, 236), (233, 150, 122))
        lf, pos = leafsh(d, bx0 + 6, yy + 26, 15, 40, (122, 168, 116))
        img.paste(lf, pos, lf)
        lf, pos = leafsh(d, bx1 - 6, yy, 15, -40, (122, 168, 116))
        img.paste(lf, pos, lf)
    return img

def btn_wood(pal):
    """زر بإطار خشبي دافئ"""
    base, dark, light = px(pal["base"]), px(pal["dark"]), px(pal["light"])
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([16, 24, W - 16, H - 12], radius=52, fill=(0, 0, 0, 110))
    img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(11)))
    # الإطار الخشبي: حلقة بتدرج بني + عروق
    wood = vgrad(W, H, [(0, mix(base, WHITE, 0.18)), (0.5, shade := mix(base, BLACK, 0.25)), (1, mix(base, BLACK, 0.5))])
    img.paste(wood, (0, 0), rmask(W, H, 52))
    d = ImageDraw.Draw(img)
    rnd = random.Random(hash(pal["base"]) & 0xffff)
    for k in range(26):
        y0 = rnd.randint(10, H - 10)
        d.arc([-40, y0 - 90, W + 40, y0 + 90], start=8, end=172, fill=mix(base, BLACK, 0.55), width=2)
    for k in range(10):
        y0 = rnd.randint(20, H - 20)
        d.arc([-30, y0 - 60, W + 30, y0 + 60], start=10, end=170, fill=mix(base, WHITE, 0.22), width=1)
    # الوجه الداخلي الفاتح
    ci = 46
    face = vgrad(W - ci * 2, H - ci * 2, [(0, mix(base, WHITE, 0.62)), (1, mix(base, WHITE, 0.42))])
    img.paste(face, (ci, ci), rmask(W - ci * 2, H - ci * 2, 30))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([ci - 3, ci - 3, W - ci + 2, H - ci + 2], radius=32, outline=mix(base, BLACK, 0.6), width=3)
    d.rounded_rectangle([ci, ci, W - ci - 1, H - ci - 1], radius=30, outline=mix(base, WHITE, 0.5), width=2)
    return img

def btn_nature(pal):
    """زر بإطار طبيعي: كرمة وأوراق"""
    base, dark, light = px(pal["base"]), px(pal["dark"]), px(pal["light"])
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([16, 24, W - 16, H - 12], radius=60, fill=(0, 0, 0, 95))
    img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(11)))
    body = vgrad(W, H, [(0, mix(base, WHITE, 0.30)), (0.5, base), (1, mix(base, BLACK, 0.34))])
    img.paste(body, (0, 0), rmask(W, H, 60))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([9, 11, W - 10, H - 10], radius=58, outline=mix(base, WHITE, 0.45), width=3)
    gloss = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(gloss).ellipse([46, -H * 0.26, W - 46, H * 0.30], fill=(255, 255, 255, 58))
    img = Image.alpha_composite(img, gloss.filter(ImageFilter.GaussianBlur(13)))
    d = ImageDraw.Draw(img)
    ci = 58
    img.paste(vgrad(W - ci * 2, H - ci * 2, [(0, mix(base, WHITE, 0.52)), (1, mix(base, WHITE, 0.36))]),
              (ci, ci), rmask(W - ci * 2, H - ci * 2, 42))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([ci, ci, W - ci - 1, H - ci - 1], radius=42, outline=mix(base, BLACK, 0.22), width=2)
    # كرمة جانبية بأوراق
    vine = (86, 132, 74)
    bx0, by0, bx1, by1 = 30, 36, W - 30, H - 36
    d.line([(bx0 + 4, by0 + 14), (bx0 + 4, by1 - 14)], fill=vine, width=3)
    d.line([(bx1 - 4, by0 + 14), (bx1 - 4, by1 - 14)], fill=vine, width=3)
    for yy in range(by0 + 24, by1 - 12, 40):
        lf, pos = leafsh(d, bx0 + 8, yy, 17, 38, (110, 160, 90))
        img.paste(lf, pos, lf)
        lf, pos = leafsh(d, bx1 - 8, yy + 20, 17, -38, (110, 160, 90))
        img.paste(lf, pos, lf)
    for xx in range(bx0 + 34, bx1 - 20, 56):
        blossom(d, xx, by0 + 6, 12, (250, 250, 240), (212, 180, 60))
        blossom(d, xx + 28, by1 - 6, 12, (250, 250, 240), (212, 180, 60))
    return img

BUILD = {"glass": btn_glass, "floral": btn_floral, "wood": btn_wood, "nature": btn_nature}

# ================= الخلفيات المشهدية =================
def bg_scene(family, pal):
    base = px(pal["base"])
    img = vgrad(BW, BH, [(0, mix(base, BLACK, 0.55)), (0.55, mix(base, BLACK, 0.30)), (1, mix(base, BLACK, 0.62))])
    img = img.convert("RGBA")
    d = ImageDraw.Draw(img)
    rnd = random.Random(hash(family + pal["base"]) & 0xffff)
    if family == "nature":
        sky = vgrad(BW, BH, [(0, mix((150, 200, 235), base, 0.35)), (0.6, mix((210, 235, 210), base, 0.25)), (1, (38, 66, 44))])
        img.paste(sky, (0, 0))
        d = ImageDraw.Draw(img)
        d.ellipse([BW * 0.62, BH * 0.10, BW * 0.92, BH * 0.24], fill=(255, 244, 200, 200))
        for layer, (yy, col) in enumerate([(0.52, (74, 108, 78)), (0.62, (52, 82, 58)), (0.72, (34, 58, 40))]):
            pts = [(0, BH)]
            x = 0
            while x < BW:
                pts.append((x, int(BH * yy) - rnd.randint(0, 90)))
                x += rnd.randint(60, 130)
            pts += [(BW, BH)]
            d.polygon(pts, fill=col)
        for k in range(14):
            tx, ty = rnd.randint(20, BW - 20), rnd.randint(int(BH * 0.74), BH - 40)
            th_ = rnd.randint(70, 130)
            d.polygon([(tx, ty - th_), (tx - th_ // 3, ty), (tx + th_ // 3, ty)], fill=(24, 44, 30))
        mist = Image.new("RGBA", (BW, BH), (0, 0, 0, 0))
        ImageDraw.Draw(mist).ellipse([-100, int(BH * 0.60), BW + 100, int(BH * 0.74)], fill=(255, 255, 255, 60))
        img = Image.alpha_composite(img, mist.filter(ImageFilter.GaussianBlur(30)))
    elif family == "celeb":
        img.paste(vgrad(BW, BH, [(0, (16, 12, 24)), (0.6, (34, 22, 40)), (1, (10, 8, 14))]), (0, 0))
        d = ImageDraw.Draw(img)
        beam = Image.new("RGBA", (BW, BH), (0, 0, 0, 0))
        bd = ImageDraw.Draw(beam)
        for cx in (BW * 0.25, BW * 0.5, BW * 0.75):
            bd.polygon([(cx, -40), (cx - 190, BH), (cx + 190, BH)], fill=(255, 214, 120, 46))
        img = Image.alpha_composite(img, beam.filter(ImageFilter.GaussianBlur(24)))
        d = ImageDraw.Draw(img)
        for k in range(46):
            gx, gy, gr = rnd.randint(0, BW), rnd.randint(0, BH), rnd.randint(8, 46)
            a = rnd.randint(40, 130)
            col = rnd.choice([(255, 214, 120, a), (255, 240, 200, a), (240, 180, 220, a)])
            d.ellipse([gx - gr, gy - gr, gx + gr, gy + gr], fill=col)
        d.rectangle([0, int(BH * 0.86), BW, BH], fill=(24, 16, 28))
        for k in range(24):
            d.ellipse([k * 32 - 6, int(BH * 0.86) - 6, k * 32 + 6, int(BH * 0.86) + 6], fill=(255, 224, 150, 200))
    elif family == "romantic":
        img.paste(vgrad(BW, BH, [(0, mix((255, 170, 190), base, 0.30)), (0.55, mix((196, 110, 160), base, 0.25)), (1, (58, 26, 66))]), (0, 0))
        d = ImageDraw.Draw(img)
        d.ellipse([BW * 0.30, BH * 0.16, BW * 0.70, BH * 0.30], fill=(255, 236, 210, 170))
        hb = Image.new("RGBA", (BW, BH), (0, 0, 0, 0))
        hd = ImageDraw.Draw(hb)
        for k in range(16):
            hx_, hy_, hr = rnd.randint(30, BW - 30), rnd.randint(60, BH - 60), rnd.randint(16, 60)
            heartsh(hd, hx_, hy_, hr, (255, 214, 228, rnd.randint(36, 90)))
        img = Image.alpha_composite(img, hb.filter(ImageFilter.GaussianBlur(3)))
        d = ImageDraw.Draw(img)
        for k in range(40):
            sx_, sy_ = rnd.randint(0, BW - 4), rnd.randint(0, BH // 2)
            d.ellipse([sx_, sy_, sx_ + 3, sy_ + 3], fill=(255, 255, 255, 170))
    elif family == "rose":
        img.paste(vgrad(BW, BH, [(0, mix((150, 26, 44), base, 0.25)), (0.6, (96, 16, 32)), (1, (40, 6, 16))]), (0, 0))
        d = ImageDraw.Draw(img)
        for k in range(9):
            cx, cy, rr = rnd.randint(60, BW - 60), rnd.randint(80, BH - 80), rnd.randint(50, 120)
            for t in range(5, 0, -1):
                col = mix((196, 48, 72), (255, 190, 200), (5 - t) / 6.0)
                d.ellipse([cx - rr * t / 5, cy - rr * t / 5, cx + rr * t / 5, cy + rr * t / 5], outline=col, width=6)
            d.ellipse([cx - rr * 0.16, cy - rr * 0.16, cx + rr * 0.16, cy + rr * 0.16], fill=(120, 20, 36))
        for k in range(20):
            px_, py_ = rnd.randint(0, BW), rnd.randint(0, BH)
            d.ellipse([px_, py_, px_ + 14, py_ + 8], fill=(220, 120, 140, 150))
    elif family == "snow":
        img.paste(vgrad(BW, BH, [(0, mix((190, 224, 246), base, 0.25)), (0.6, (140, 184, 220)), (1, (70, 104, 140))]), (0, 0))
        d = ImageDraw.Draw(img)
        d.polygon([(0, int(BH * 0.78)), (BW * 0.3, int(BH * 0.70)), (BW * 0.62, int(BH * 0.80)), (BW, int(BH * 0.72)), (BW, BH), (0, BH)], fill=(246, 250, 255))
        d.polygon([(0, int(BH * 0.86)), (BW * 0.45, int(BH * 0.80)), (BW, int(BH * 0.88)), (BW, BH), (0, BH)], fill=(255, 255, 255))
        for k in range(26):
            snowf(d, rnd.randint(20, BW - 20), rnd.randint(20, int(BH * 0.72)), rnd.randint(10, 30), (255, 255, 255, rnd.randint(120, 220)))
        for k in range(30):
            gx, gy, gr = rnd.randint(0, BW), rnd.randint(0, BH), rnd.randint(6, 26)
            d.ellipse([gx - gr, gy - gr, gx + gr, gy + gr], fill=(255, 255, 255, rnd.randint(30, 80)))
    else:  # flowers
        img.paste(vgrad(BW, BH, [(0, mix((250, 230, 240), base, 0.30)), (0.6, mix((214, 236, 210), base, 0.25)), (1, (86, 116, 84))]), (0, 0))
        d = ImageDraw.Draw(img)
        for k in range(12):
            sx = rnd.randint(40, BW - 40)
            d.arc([sx - 60, int(BH * 0.55), sx + 60, BH], start=0, end=180, fill=(96, 140, 90), width=5)
        for k in range(22):
            blossom(d, rnd.randint(40, BW - 40), rnd.randint(60, BH - 60), rnd.randint(22, 54),
                    rnd.choice([(255, 244, 248), (252, 226, 236), (240, 226, 252), (255, 240, 214)]), (240, 190, 90))
        for k in range(26):
            lf, pos = leafsh(d, rnd.randint(20, BW - 20), rnd.randint(int(BH * 0.5), BH - 20), rnd.randint(20, 40), rnd.randint(-60, 60), (110, 156, 96))
            img.paste(lf, pos, lf)
    return img.convert("RGB")

# ================= بيانات المجموعات الجديدة =================
SETS_NEW = [
    ("glass", "شفاف زجاجي"),
    ("floral", "حواف زهرية"),
    ("wood", "حواف خشبية"),
    ("nature", "إطارات طبيعية"),
]
PALETTES = {
 "glass": [("ice","#cfe8f5","#33566b","#eaf6fc","جليدي"),("white","#eef4f8","#46586a","#f8fbfd","لؤلؤي"),
           ("silver","#d8dce2","#3f434a","#f0f2f5","فضي"),("blue","#9cc4e8","#274a63","#d3e6f6","أزرق"),
           ("mint","#bfe6da","#2c5a4c","#e2f5ef","نعناعي"),("purple","#cbb7e8","#46366b","#e8dff6","بنفسجي"),
           ("pink","#f3cdd7","#6b3a48","#fae7ec","وردي"),("gold","#e8d7b0","#6b5a33","#f6edda","ذهبي"),
           ("ruby","#e8a7ad","#6b2730","#f6d6d9","ياقوتي"),("green","#c4ddb4","#3d5a33","#e4f0da","أخضر"),
           ("night","#9aa7c0","#232c42","#d0d8e8","ليلي"),("peach","#f5d3ba","#6b4a33","#faeadd","خوخي")],
 "floral": [("rose","#e87a90","#5c1f2c","#f6c0ca","وردي"),("pink","#f2a7c3","#632941","#fad6e4","وردي"),
           ("ruby","#d94f5c","#57171e","#f0aeb4","ياقوتي"),("purple","#c07ad0","#47264f","#e4c2ec","بنفسجي"),
           ("white","#f6e8ee","#5f4a52","#fbf5f8","لؤلؤي"),("red","#c03434","#4a0d0d","#e69a9a","أحمر"),
           ("lav","#b79ae0","#3f2c66","#e0d2f2","بنفسجي"),("peach","#f0b28f","#63392a","#f8dcc9","خوخي"),
           ("magenta","#d060a8","#521c40","#ecb4d8","وردي"),("cream","#f2e3d0","#5c5040","#f9f2e8","لؤلؤي"),
           ("blue","#8fb7e0","#263c5c","#cadff2","أزرق"),("mint","#a8dcc8","#2c5546","#d8f0e6","نعناعي")],
 "wood": [("oak","#b98a5a","#3d2a17","#e0c6a8","بلوطي"),("walnut","#8a5f3c","#2b1c0e","#c8a888","جوزي"),
           ("amber","#d0a060","#4a3319","#ead0a8","عنبري"),("ebony","#5a4632","#1c150c","#a89078","أبنوسي"),
           ("olive","#9a8a52","#332c17","#d0c498","زيتوني"),("cherry","#9a4a3a","#331410","#d0a098","كرزي"),
           ("maple","#c87840","#422412","#e8bc98","قيقبي"),("ash","#c0b098","#3f382e","#e4d8c8","رمادي"),
           ("mahog","#7a3028","#280e0b","#c09890","ماهوجني"),("pine","#7a8a5a","#28301c","#c0c8a8","صنوبري"),
           ("teak","#a07048","#352214","#d4b498","تيكي"),("birch","#e0d0b8","#4a4238","#f2e8d8","أبيض")],
 "nature": [("leaf","#7ab648","#264016","#c0e0a0","أخضر"),("mint","#66c2a0","#1f4636","#b4e4d2","نعناعي"),
           ("lime","#b8d430","#3d470e","#e0ec98","ليموني"),("forest","#3d7a3d","#122812","#98c098","حرجي"),
           ("sky","#7ab8e0","#24425c","#c0dff2","سماوي"),("earth","#a08050","#352a18","#d4c0a0","ترابي"),
           ("moss","#8a9a4a","#2c3316","#c8d0a0","طحلبي"),("fern","#5aa06a","#1c3522","#acd4b4","سرخسي"),
           ("sage","#a8b898","#373f30","#d8e0cc","مريمي"),("teal","#4aa8a0","#173835","#a0d8d4","أزرق مخضر"),
           ("olive2","#b0a838","#3a3712","#dcd898","زيتوني"),("ivory","#e8e4d0","#4c4a40","#f6f4ea","عاجي")],
}
FAMILY = {
 "glass": lambda ck: "snow" if ck in ("ice", "blue", "mint", "silver", "white", "night") else "celeb",
 "floral": lambda ck: "rose" if ck in ("rose", "ruby", "red", "magenta", "pink") else "flowers",
 "wood":   lambda ck: "romantic" if ck in ("cherry", "mahog") else "nature",
 "nature": lambda ck: "nature" if ck in ("leaf", "lime", "forest", "moss", "fern", "sage", "olive2") else ("romantic" if ck in ("sky",) else "flowers"),
}
FAM_AR = {"nature": "طبيعة", "celeb": "مشاهير", "romantic": "رومانسي", "rose": "ورود جورية", "snow": "ثلوج", "flowers": "زهور"}

# ================= التنفيذ =================
s = open(os.path.join(PUB, "assets", "data.js"), encoding="utf-8").read()
D = json.loads(s[len("window.LIB = "):-2])
have = {b["id"] for b in D["buttons"]}
added = 0
for sid, sar in SETS_NEW:
    if sid not in {x["id"] for x in D["sets"]}:
        D["sets"].append({"id": sid, "ar": sar})
    for i, row in enumerate(PALETTES[sid], 1):
        ck, base, dark, light, car = row[0], row[1], row[2], row[3], row[4]
        bid = f"{sid}-{i:02d}"
        if bid in have:
            continue
        pal = {"base": base, "dark": dark, "light": light}
        img = BUILD[sid](pal)
        img.save(os.path.join(BTN, f"btn-{bid}.png"), optimize=True)
        fam = FAMILY[sid](ck)
        bg = bg_scene(fam, pal)
        bg.save(os.path.join(BGD, f"bg-{bid}.jpg"), quality=88, optimize=True)
        # theme.css
        p = mix(px(base), (255, 255, 255), 0.45)
        lum = 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]
        txt = dark if lum > 150 else hx(mix(px(light), (255, 255, 255), 0.45))
        open(os.path.join(CSS, f"theme-{bid}.css"), "w", encoding="utf-8").write(
            f"""/* ثيماتي — ثيم «{car} — {sar} {i}» (موحّد: خلفية + زر + لون خط متناسق) */
:root {{
  --theme-accent: {base};
  --theme-accent-dark: {dark};
  --theme-accent-light: {light};
  --theme-text: {txt};
  --theme-wallpaper: url("../backgrounds/bg-{bid}.jpg");
  --theme-keycap: url("../buttons/btn-{bid}.png");
}}
.keyboard {{ background: var(--theme-wallpaper) center/cover; padding: 14px; border-radius: 22px; }}
.key {{
  background: var(--theme-keycap) center/100% 100% no-repeat;
  color: var(--theme-text);
  border: none; width: 52px; height: 70px; cursor: pointer;
  transition: transform .12s ease, filter .12s ease;
}}
.key:active {{ transform: translateY(3px) scale(.96); filter: brightness(1.15); }}
""")
        D["buttons"].append({"id": bid, "set": sid, "setAr": sar, "colorKey": ck, "colorAr": car,
                             "name": f"{car} — {sar} {i}", "src": f"assets/buttons/btn-{bid}.png",
                             "css": f"assets/themes-css/theme-{bid}.css", "palette": pal})
        D["backgrounds"].append({"id": bid, "name": f"خلفية {car} — {FAM_AR[fam]} {i}",
                                 "src": f"assets/backgrounds/bg-{bid}.jpg", "forButton": bid,
                                 "palette": pal})
        added += 1

open(os.path.join(PUB, "assets", "data.js"), "w", encoding="utf-8").write("window.LIB = " + json.dumps(D, ensure_ascii=False) + ";\n")
print(f"تمت إضافة {added} زراً وخلفية وثيماً جديداً — الإجمالي: {len(D['buttons'])} زر / {len(D['backgrounds'])} خلفية / {len(D['sets'])} مجموعات")
